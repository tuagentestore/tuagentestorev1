'use client';

import Link from 'next/link';
import { Bot, ArrowRight, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { categoryColors, categoryLabels } from '@/lib/brand';
import type { AgentPublic } from '@/lib/api-client';

interface AgentCardProps {
  agent: AgentPublic;
}

export default function AgentCard({ agent }: AgentCardProps) {
  const catColor = categoryColors[agent.category] || 'bg-primary/10 text-primary border-primary/20';
  const catLabel = categoryLabels[agent.category] || agent.category;

  return (
    <Card className="group border-border hover:border-primary/30 transition-all hover:shadow-custom overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/20 transition-colors">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <Badge className={catColor}>{catLabel}</Badge>
        </div>

        <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
          {agent.name}
        </h3>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{agent.tagline}</p>

        {/* Capabilities */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {(agent.capabilities as string[]).slice(0, 3).map((cap, idx) => (
            <Badge key={idx} variant="outline" className="text-xs">
              {cap}
            </Badge>
          ))}
          {(agent.capabilities as string[]).length > 3 && (
            <Badge variant="outline" className="text-xs">+{(agent.capabilities as string[]).length - 3}</Badge>
          )}
        </div>

        {/* Pricing */}
        {agent.pricingBasic && (
          <p className="text-sm text-muted-foreground mb-4">
            Desde <span className="font-semibold text-foreground">${agent.pricingBasic}/mes</span>
          </p>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          <Link href={`/agente/${agent.slug}`} className="flex-1">
            <Button variant="outline" size="sm" className="w-full">
              Ver Detalle
            </Button>
          </Link>
          {agent.demoAvailable && (
            <Link href={`/demo/${agent.slug}`}>
              <Button size="sm" className="gap-1">
                <Sparkles className="w-3.5 h-3.5" /> Demo
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
