'use client';

import Link from 'next/link';
import { Bot } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-card border-t border-border mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 bg-primary rounded-lg flex items-center justify-center shadow-custom">
                <Bot className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold text-primary">Catharsis IA</span>
            </Link>
            <p className="text-foreground mb-4">
              Agentes IA listos para automatizar tu negocio.
            </p>
            <p className="text-sm text-muted-foreground">
              Transformá tu negocio con automatización inteligente 24/7.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Producto</h3>
            <ul className="space-y-2">
              <li><Link href="/catalogo" className="text-muted-foreground hover:text-primary transition-colors">Catálogo de Agentes</Link></li>
              <li><Link href="/#como-funciona" className="text-muted-foreground hover:text-primary transition-colors">Cómo Funciona</Link></li>
              <li><Link href="/#precios" className="text-muted-foreground hover:text-primary transition-colors">Precios</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Soporte</h3>
            <ul className="space-y-2">
              <li><a href="mailto:hola@catharsis-ia.com" className="text-muted-foreground hover:text-primary transition-colors">Contacto</a></li>
              <li><span className="text-muted-foreground">Documentación</span></li>
              <li><a href="mailto:soporte@catharsis-ia.com" className="text-muted-foreground hover:text-primary transition-colors">Soporte Técnico</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Catharsis IA. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}
