'use client';

import React from 'react';
import { useAuth } from '@/hooks/useAuth';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { loadUser } = useAuth();

  React.useEffect(() => {
    loadUser();
  }, [loadUser]);

  return <>{children}</>;
}
