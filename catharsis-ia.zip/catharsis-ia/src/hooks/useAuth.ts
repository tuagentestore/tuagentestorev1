'use client';

import { create } from 'zustand';
import { api, type AuthUser } from '@/lib/api-client';

interface AuthState {
  user: AuthUser | null;
  loading: boolean;
  error: string | null;
  
  // Actions
  loadUser: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { email: string; password: string; fullName: string; phone?: string; company?: string }) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user: null,
  loading: true,
  error: null,

  loadUser: async () => {
    try {
      set({ loading: true, error: null });
      const user = await api.auth.me();
      set({ user, loading: false });
    } catch {
      set({ user: null, loading: false });
    }
  },

  login: async (email, password) => {
    try {
      set({ loading: true, error: null });
      const { user } = await api.auth.login(email, password);
      set({ user, loading: false });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Error al iniciar sesión';
      set({ error: message, loading: false });
      throw error;
    }
  },

  register: async (data) => {
    try {
      set({ loading: true, error: null });
      const { user } = await api.auth.register(data);
      set({ user, loading: false });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Error al registrarse';
      set({ error: message, loading: false });
      throw error;
    }
  },

  logout: async () => {
    try {
      await api.auth.logout();
    } catch {
      // Ignore logout errors
    } finally {
      set({ user: null, loading: false, error: null });
      window.location.href = '/';
    }
  },

  clearError: () => set({ error: null }),
}));
