import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const DEFAULT_MODEL = process.env.OPENAI_DEFAULT_MODEL || 'gpt-4o-mini';
const PREMIUM_MODEL = process.env.OPENAI_PREMIUM_MODEL || 'gpt-4o';

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function chatCompletion(
  messages: ChatMessage[],
  options?: {
    model?: string;
    maxTokens?: number;
    temperature?: number;
  }
): Promise<string> {
  const response = await openai.chat.completions.create({
    model: options?.model || DEFAULT_MODEL,
    messages,
    max_tokens: options?.maxTokens || 500,
    temperature: options?.temperature || 0.7,
  });

  return response.choices[0]?.message?.content || '';
}

export async function demoChat(
  systemPrompt: string,
  conversation: { role: string; content: string }[],
  userMessage: string
): Promise<string> {
  const messages: ChatMessage[] = [
    { role: 'system', content: systemPrompt },
    ...conversation.map((msg) => ({
      role: msg.role as 'user' | 'assistant',
      content: msg.content,
    })),
    { role: 'user', content: userMessage },
  ];

  return chatCompletion(messages, {
    model: DEFAULT_MODEL,
    maxTokens: 300,
    temperature: 0.7,
  });
}

export async function generateRecommendations(
  problems: string,
  companySize: string,
  budget: string
): Promise<string> {
  const messages: ChatMessage[] = [
    {
      role: 'system',
      content: 'Eres un experto en automatización con IA para empresas hispanas. Responde SOLO en JSON válido sin markdown.',
    },
    {
      role: 'user',
      content: `Problemas: ${problems}\nTamaño: ${companySize}\nPresupuesto: ${budget}\n\nRecomienda 3-4 agentes IA en JSON: {"recommendations": [{"name": "...", "problem": "...", "roi": "...", "difficulty": "Baja/Media/Alta", "next_steps": "..."}]}`,
    },
  ];

  return chatCompletion(messages, {
    model: DEFAULT_MODEL,
    maxTokens: 800,
    temperature: 0.5,
  });
}
