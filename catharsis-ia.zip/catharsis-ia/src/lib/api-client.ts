// Frontend API client - replaces base44 SDK
const BASE = '';

async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${url}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options?.headers,
    },
    credentials: 'include',
  });

  const json = await res.json();

  if (!res.ok || !json.ok) {
    throw new ApiError(json.error || 'Error desconocido', res.status, json.details);
  }

  return json.data as T;
}

export class ApiError extends Error {
  status: number;
  details?: unknown;
  constructor(message: string, status: number, details?: unknown) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

// ─── Auth ─────────────────────────────────────────────────────
export const auth = {
  me: () => request<AuthUser>('/api/auth/me'),
  login: (email: string, password: string) =>
    request<{ user: AuthUser; accessToken: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),
  register: (data: { email: string; password: string; fullName: string; phone?: string; company?: string }) =>
    request<{ user: AuthUser; accessToken: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  logout: () => request('/api/auth/logout', { method: 'POST' }),
  refresh: (refreshToken: string) =>
    request<{ accessToken: string; refreshToken: string }>('/api/auth/refresh', {
      method: 'POST',
      body: JSON.stringify({ refreshToken }),
    }),
};

// ─── Agents ───────────────────────────────────────────────────
export const agents = {
  list: (params?: { category?: string; featured?: boolean }) => {
    const search = new URLSearchParams();
    if (params?.category) search.set('category', params.category);
    if (params?.featured) search.set('featured', 'true');
    return request<AgentPublic[]>(`/api/agents?${search}`);
  },
  get: (slug: string) => request<AgentPublic>(`/api/agents/${slug}`),
};

// ─── Demos ────────────────────────────────────────────────────
export const demos = {
  create: (agentId: string, visitorEmail?: string, visitorName?: string) =>
    request<DemoSession>('/api/demos', {
      method: 'POST',
      body: JSON.stringify({ agentId, visitorEmail, visitorName }),
    }),
  sendMessage: (demoId: string, message: string) =>
    request<{ reply: string; messagesUsed: number; maxMessages: number; status: string }>(
      `/api/demos/${demoId}/message`,
      { method: 'POST', body: JSON.stringify({ message }) }
    ),
  get: (id: string) => request<DemoSession>(`/api/demos/${id}`),
};

// ─── Reservations ─────────────────────────────────────────────
export const reservations = {
  create: (data: CreateReservationData) =>
    request<{ id: string }>('/api/reservations', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ─── Recommendations ─────────────────────────────────────────
export const recommendations = {
  generate: (data: { problems: string[]; companySize: string; budget: string }) =>
    request<{ recommendations: Recommendation[] }>('/api/agents/recommend', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
};

// ─── Admin ────────────────────────────────────────────────────
export const admin = {
  dashboard: () => request<AdminDashboard>('/api/admin/dashboard'),
  reservations: (params?: { status?: string }) => {
    const search = new URLSearchParams();
    if (params?.status) search.set('status', params.status);
    return request<ReservationAdmin[]>(`/api/reservations?${search}`);
  },
  updateReservation: (id: string, data: { status?: string; adminNotes?: string }) =>
    request(`/api/reservations/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),
};

// ─── Types ────────────────────────────────────────────────────
export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: string;
  tenantId: string | null;
  avatarUrl: string | null;
}

export interface AgentPublic {
  id: string;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  longDescription: string | null;
  category: string;
  capabilities: string[];
  integrations: string[];
  imageUrl: string | null;
  iconName: string | null;
  status: string;
  pricingBasic: number | null;
  pricingPro: number | null;
  pricingEnterprise: number | null;
  demoAvailable: boolean;
  featured: boolean;
  faqs: { question: string; answer: string }[];
  howItWorks: string | null;
  implementation: string | null;
  installTime: string | null;
  requirements: string | null;
  automatedTasks: string[];
}

export interface DemoSession {
  id: string;
  agentId: string;
  messagesUsed: number;
  maxMessages: number;
  conversation: { role: string; content: string; timestamp?: string }[];
  status: string;
}

export interface CreateReservationData {
  agentId: string;
  userName: string;
  userEmail: string;
  company?: string;
  phone: string;
  industry?: string;
  useCase?: string;
  planInterest?: string;
  preferredDate?: string;
  notes?: string;
  demoSessionId?: string;
}

export interface ReservationAdmin {
  id: string;
  agentId: string;
  userName: string;
  userEmail: string;
  company: string | null;
  phone: string;
  industry: string | null;
  useCase: string | null;
  planInterest: string;
  status: string;
  preferredDate: string | null;
  notes: string | null;
  adminNotes: string | null;
  createdAt: string;
  agent: { name: string };
}

export interface AdminDashboard {
  totalReservations: number;
  pendingReservations: number;
  totalDemos: number;
  conversionRate: number;
  recentReservations: ReservationAdmin[];
}

export interface Recommendation {
  name: string;
  problem: string;
  roi: string;
  difficulty: string;
  next_steps: string;
}

export const api = { auth, agents, demos, reservations, recommendations, admin };
export default api;
