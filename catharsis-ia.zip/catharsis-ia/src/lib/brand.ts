export const BRAND = {
  name: 'Catharsis IA',
  tagline: 'Agentes IA listos para automatizar tu negocio',
  description: 'Marketplace de agentes de inteligencia artificial. Probá, reservá e implementá automatizaciones que trabajan 24/7.',
  email: 'hola@catharsis-ia.com',
  supportEmail: 'soporte@catharsis-ia.com',
} as const;

export const categoryColors: Record<string, string> = {
  Marketing: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  Ventas: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
  'Atención al Cliente': 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  Atencion_al_Cliente: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  Datos: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  Legal: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  Operaciones: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
};

export const categoryLabels: Record<string, string> = {
  Marketing: 'Marketing',
  Ventas: 'Ventas',
  Atencion_al_Cliente: 'Atención al Cliente',
  Datos: 'Datos',
  Legal: 'Legal',
  Operaciones: 'Operaciones',
};

export const industryOptions = [
  'Seguros',
  'Inmobiliaria',
  'Legal',
  'Tecnología',
  'Salud',
  'Retail',
  'Educación',
  'Finanzas',
  'Manufactura',
  'Otro',
] as const;

export const planInterestOptions = ['Básico', 'Pro', 'Enterprise'] as const;
