import { NextResponse } from 'next/server';
import { z, ZodError } from 'zod';

// ─── Standard API Responses ──────────────────────────────────
export function apiSuccess<T>(data: T, status = 200) {
  return NextResponse.json({ ok: true, data }, { status });
}

export function apiError(message: string, status = 400, details?: unknown) {
  return NextResponse.json(
    { ok: false, error: message, details },
    { status }
  );
}

export function apiUnauthorized(message = 'No autorizado') {
  return apiError(message, 401);
}

export function apiForbidden(message = 'Acceso denegado') {
  return apiError(message, 403);
}

export function apiNotFound(message = 'No encontrado') {
  return apiError(message, 404);
}

export function apiServerError(message = 'Error interno del servidor') {
  return apiError(message, 500);
}

// ─── Handle Auth Errors ──────────────────────────────────────
export function handleAuthError(error: unknown) {
  if (error instanceof Error) {
    if (error.message === 'UNAUTHORIZED') return apiUnauthorized();
    if (error.message === 'FORBIDDEN') return apiForbidden();
  }
  return apiServerError();
}

// ─── Validate Request Body ───────────────────────────────────
export async function validateBody<T>(
  request: Request,
  schema: z.ZodSchema<T>
): Promise<{ data: T; error?: never } | { data?: never; error: NextResponse }> {
  try {
    const body = await request.json();
    const data = schema.parse(body);
    return { data };
  } catch (error) {
    if (error instanceof ZodError) {
      const messages = error.errors.map(e => `${e.path.join('.')}: ${e.message}`);
      return { error: apiError('Datos inválidos', 422, messages) };
    }
    return { error: apiError('Body inválido', 400) };
  }
}

// ─── Webhook Log ─────────────────────────────────────────────
import { db } from './db';

export async function logWebhook(
  source: string,
  eventType: string,
  payload: unknown,
  status: string = 'received',
  error?: string
) {
  try {
    await db.webhookLog.create({
      data: {
        source,
        eventType,
        payload: payload as any,
        status,
        error,
        processedAt: status === 'processed' ? new Date() : null,
      },
    });
  } catch (e) {
    console.error('[webhook-log] Failed to log:', e);
  }
}

// ─── Rate Limiting (simple in-memory) ────────────────────────
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

export function checkRateLimit(
  key: string,
  maxRequests: number = 10,
  windowMs: number = 60000
): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(key);

  if (!entry || entry.resetAt < now) {
    rateLimitStore.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }

  if (entry.count >= maxRequests) {
    return false;
  }

  entry.count++;
  return true;
}

// Cleanup old entries periodically
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of rateLimitStore.entries()) {
    if (entry.resetAt < now) rateLimitStore.delete(key);
  }
}, 60000);
