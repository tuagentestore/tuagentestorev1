import { z } from 'zod';

// ─── Auth ─────────────────────────────────────────────────────
export const registerSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(8, 'Mínimo 8 caracteres').max(128),
  fullName: z.string().min(2, 'Nombre requerido').max(200),
  phone: z.string().optional(),
  company: z.string().optional(),
});

export const loginSchema = z.object({
  email: z.string().email('Email inválido'),
  password: z.string().min(1, 'Contraseña requerida'),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(1),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email('Email inválido'),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1),
  password: z.string().min(8, 'Mínimo 8 caracteres').max(128),
});

// ─── Demos ────────────────────────────────────────────────────
export const createDemoSchema = z.object({
  agentId: z.string().uuid(),
  visitorEmail: z.string().email().optional(),
  visitorName: z.string().max(200).optional(),
});

export const demoMessageSchema = z.object({
  message: z.string().min(1, 'Mensaje requerido').max(1000),
});

// ─── Reservations ─────────────────────────────────────────────
export const createReservationSchema = z.object({
  agentId: z.string().uuid(),
  userName: z.string().min(2, 'Nombre requerido').max(200),
  userEmail: z.string().email('Email inválido'),
  company: z.string().max(200).optional(),
  phone: z.string().min(5, 'Teléfono requerido').max(50),
  industry: z.string().max(100).optional(),
  useCase: z.string().max(2000).optional(),
  planInterest: z.enum(['Básico', 'Pro', 'Enterprise']).default('Básico'),
  preferredDate: z.string().optional(), // ISO date
  notes: z.string().max(2000).optional(),
  demoSessionId: z.string().uuid().optional(),
});

export const updateReservationSchema = z.object({
  status: z.enum([
    'pending', 'contacted', 'qualified', 'demo_scheduled',
    'validated', 'paid', 'implementing', 'active', 'cancelled'
  ]).optional(),
  adminNotes: z.string().max(5000).optional(),
});

// ─── Agents (Admin) ───────────────────────────────────────────
export const createAgentSchema = z.object({
  name: z.string().min(2).max(200),
  tagline: z.string().min(5).max(300),
  description: z.string().min(10),
  longDescription: z.string().optional(),
  category: z.enum(['Marketing', 'Ventas', 'Atencion_al_Cliente', 'Datos', 'Legal', 'Operaciones']),
  capabilities: z.array(z.string()).default([]),
  integrations: z.array(z.string()).default([]),
  imageUrl: z.string().url().optional(),
  iconName: z.string().max(50).optional(),
  status: z.enum(['active', 'coming_soon', 'beta', 'inactive']).default('active'),
  pricingBasic: z.number().min(0).optional(),
  pricingPro: z.number().min(0).optional(),
  pricingEnterprise: z.number().min(0).optional(),
  demoPrompt: z.string().optional(),
  demoAvailable: z.boolean().default(true),
  featured: z.boolean().default(false),
  faqs: z.array(z.object({ question: z.string(), answer: z.string() })).default([]),
});

// ─── Onboarding ───────────────────────────────────────────────
export const onboardingSchema = z.object({
  reservationId: z.string().uuid().optional(),
  formData: z.record(z.unknown()),
});

// ─── Recommendations Wizard ───────────────────────────────────
export const recommendationSchema = z.object({
  problems: z.array(z.string()).min(1, 'Seleccioná al menos un problema'),
  companySize: z.string().min(1),
  budget: z.string().min(1),
});

// ─── Type exports ─────────────────────────────────────────────
export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateDemoInput = z.infer<typeof createDemoSchema>;
export type DemoMessageInput = z.infer<typeof demoMessageSchema>;
export type CreateReservationInput = z.infer<typeof createReservationSchema>;
export type UpdateReservationInput = z.infer<typeof updateReservationSchema>;
export type CreateAgentInput = z.infer<typeof createAgentSchema>;
export type RecommendationInput = z.infer<typeof recommendationSchema>;
