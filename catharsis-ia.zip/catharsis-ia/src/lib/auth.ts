import jwt from 'jsonwebtoken';
import { hash, compare } from 'bcryptjs';
import { cookies } from 'next/headers';
import { NextRequest } from 'next/server';
import { db } from './db';
import { v4 as uuidv4 } from 'uuid';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';
const REFRESH_TOKEN_EXPIRES_IN = process.env.REFRESH_TOKEN_EXPIRES_IN || '30d';
const BCRYPT_ROUNDS = parseInt(process.env.BCRYPT_ROUNDS || '12');

// ─── Token Types ──────────────────────────────────────────────
export interface TokenPayload {
  userId: string;
  email: string;
  role: string;
  tenantId?: string;
}

export interface AuthUser {
  id: string;
  email: string;
  fullName: string;
  role: string;
  tenantId: string | null;
  avatarUrl: string | null;
}

// ─── Password Hashing ────────────────────────────────────────
export async function hashPassword(password: string): Promise<string> {
  return hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return compare(password, hashedPassword);
}

// ─── JWT Token Generation ────────────────────────────────────
export function generateAccessToken(payload: TokenPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

export function generateRefreshToken(): string {
  return uuidv4() + '-' + uuidv4();
}

export function verifyAccessToken(token: string): TokenPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as TokenPayload;
  } catch {
    return null;
  }
}

// ─── Session Management ──────────────────────────────────────
function parseExpiry(expiresIn: string): number {
  const match = expiresIn.match(/^(\d+)([dhms])$/);
  if (!match) return 7 * 24 * 60 * 60 * 1000; // default 7d
  const [, num, unit] = match;
  const multipliers: Record<string, number> = {
    's': 1000, 'm': 60000, 'h': 3600000, 'd': 86400000,
  };
  return parseInt(num) * (multipliers[unit] || 86400000);
}

export async function createSession(
  userId: string,
  req?: NextRequest
): Promise<{ accessToken: string; refreshToken: string; expiresAt: Date }> {
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, email: true, role: true, tenantId: true },
  });
  
  if (!user) throw new Error('User not found');

  const tokenPayload: TokenPayload = {
    userId: user.id,
    email: user.email,
    role: user.role,
    tenantId: user.tenantId || undefined,
  };

  const accessToken = generateAccessToken(tokenPayload);
  const refreshToken = generateRefreshToken();
  const expiresAt = new Date(Date.now() + parseExpiry(REFRESH_TOKEN_EXPIRES_IN));

  await db.session.create({
    data: {
      userId,
      token: accessToken,
      refreshToken,
      ipAddress: req?.headers.get('x-forwarded-for')?.split(',')[0] || req?.ip || null,
      userAgent: req?.headers.get('user-agent')?.substring(0, 500) || null,
      expiresAt,
    },
  });

  // Update last login
  await db.user.update({
    where: { id: userId },
    data: { lastLoginAt: new Date() },
  });

  return { accessToken, refreshToken, expiresAt };
}

export async function revokeSession(token: string): Promise<void> {
  try {
    await db.session.deleteMany({ where: { token } });
  } catch {
    // Session might already be deleted
  }
}

export async function revokeAllSessions(userId: string): Promise<void> {
  await db.session.deleteMany({ where: { userId } });
}

// ─── Auth from Request ───────────────────────────────────────
export async function getAuthFromRequest(req: NextRequest): Promise<AuthUser | null> {
  const authHeader = req.headers.get('authorization');
  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

  if (!token) {
    // Try cookie
    const cookieStore = await cookies();
    const cookieToken = cookieStore.get('access_token')?.value;
    if (!cookieToken) return null;
    return validateTokenAndGetUser(cookieToken);
  }

  return validateTokenAndGetUser(token);
}

async function validateTokenAndGetUser(token: string): Promise<AuthUser | null> {
  const payload = verifyAccessToken(token);
  if (!payload) return null;

  // Verify session exists in DB
  const session = await db.session.findFirst({
    where: {
      token,
      expiresAt: { gt: new Date() },
    },
  });

  if (!session) return null;

  const user = await db.user.findUnique({
    where: { id: payload.userId, status: 'active' },
    select: {
      id: true,
      email: true,
      fullName: true,
      role: true,
      tenantId: true,
      avatarUrl: true,
    },
  });

  return user;
}

// ─── Refresh Token ───────────────────────────────────────────
export async function refreshSession(refreshToken: string, req?: NextRequest) {
  const session = await db.session.findFirst({
    where: {
      refreshToken,
      expiresAt: { gt: new Date() },
    },
    include: { user: { select: { id: true, status: true } } },
  });

  if (!session || session.user.status !== 'active') {
    return null;
  }

  // Delete old session
  await db.session.delete({ where: { id: session.id } });

  // Create new session
  return createSession(session.userId, req);
}

// ─── Middleware helpers ──────────────────────────────────────
export function requireAuth(user: AuthUser | null): AuthUser {
  if (!user) throw new Error('UNAUTHORIZED');
  return user;
}

export function requireAdmin(user: AuthUser | null): AuthUser {
  const authed = requireAuth(user);
  if (authed.role !== 'admin' && authed.role !== 'superadmin') {
    throw new Error('FORBIDDEN');
  }
  return authed;
}

export function requireSuperAdmin(user: AuthUser | null): AuthUser {
  const authed = requireAuth(user);
  if (authed.role !== 'superadmin') {
    throw new Error('FORBIDDEN');
  }
  return authed;
}

// ─── Clean expired sessions (called by cron) ─────────────────
export async function cleanExpiredSessions(): Promise<number> {
  const result = await db.session.deleteMany({
    where: { expiresAt: { lt: new Date() } },
  });
  return result.count;
}
