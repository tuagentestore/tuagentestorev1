import * as postmark from '@postmarkapp/postmark';

const client = new postmark.ServerClient(process.env.POSTMARK_API_KEY || '');
const FROM_EMAIL = process.env.POSTMARK_FROM_EMAIL || 'hola@catharsis-ia.com';

interface EmailOptions {
  to: string;
  subject: string;
  htmlBody: string;
  textBody?: string;
  tag?: string;
  metadata?: Record<string, string>;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    await client.sendEmail({
      From: FROM_EMAIL,
      To: options.to,
      Subject: options.subject,
      HtmlBody: options.htmlBody,
      TextBody: options.textBody || stripHtml(options.htmlBody),
      Tag: options.tag,
      Metadata: options.metadata,
      MessageStream: 'outbound',
    });
    return true;
  } catch (error) {
    console.error('[email] Send failed:', error);
    return false;
  }
}

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
}

// ─── Email Templates ─────────────────────────────────────────

function baseTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width"></head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f5f5; margin: 0; padding: 20px;">
  <div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.08);">
    <div style="background: linear-gradient(135deg, #2563EB, #7C3AED); padding: 24px 32px;">
      <h1 style="color: white; margin: 0; font-size: 20px;">✦ Catharsis IA</h1>
    </div>
    <div style="padding: 32px;">
      ${content}
    </div>
    <div style="padding: 16px 32px; background: #f9fafb; border-top: 1px solid #eee; text-align: center;">
      <p style="color: #9ca3af; font-size: 12px; margin: 0;">© ${new Date().getFullYear()} Catharsis IA. Todos los derechos reservados.</p>
    </div>
  </div>
</body>
</html>`;
}

export const emailTemplates = {
  welcomeDemo(name: string, agentName: string): EmailOptions {
    return {
      to: '', // Set by caller
      subject: `¡Probaste ${agentName}! Conocé todo su potencial`,
      htmlBody: baseTemplate(`
        <h2 style="color: #1f2937; margin-top: 0;">¡Hola ${name}! 👋</h2>
        <p style="color: #4b5563; line-height: 1.6;">Acabás de probar <strong>${agentName}</strong> en Catharsis IA. Lo que viste es apenas una muestra de lo que puede hacer por tu negocio.</p>
        <p style="color: #4b5563; line-height: 1.6;">El agente completo incluye integraciones con tus herramientas, automatizaciones 24/7 y reportes inteligentes.</p>
        <div style="text-align: center; margin: 24px 0;">
          <a href="${process.env.APP_URL}/catalogo" style="background: #2563EB; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600;">Ver todos los agentes</a>
        </div>
        <p style="color: #9ca3af; font-size: 14px;">¿Querés que te contactemos? Respondé este email y coordinamos una llamada.</p>
      `),
      tag: 'demo-welcome',
    };
  },

  reservationConfirm(name: string, agentName: string, reservationId: string): EmailOptions {
    return {
      to: '',
      subject: `✅ Reserva confirmada: ${agentName}`,
      htmlBody: baseTemplate(`
        <h2 style="color: #1f2937; margin-top: 0;">¡Reserva confirmada, ${name}! 🎉</h2>
        <p style="color: #4b5563; line-height: 1.6;">Tu reserva de <strong>${agentName}</strong> fue registrada exitosamente.</p>
        <div style="background: #f0f9ff; border: 1px solid #bae6fd; border-radius: 8px; padding: 16px; margin: 16px 0;">
          <p style="margin: 0; color: #0369a1;"><strong>ID de reserva:</strong> ${reservationId.slice(0, 8).toUpperCase()}</p>
          <p style="margin: 8px 0 0; color: #0369a1;"><strong>Próximo paso:</strong> Te contactaremos en las próximas 24 horas hábiles.</p>
        </div>
        <p style="color: #4b5563; line-height: 1.6;">Mientras tanto, podés explorar más agentes en nuestro catálogo.</p>
      `),
      tag: 'reservation-confirm',
    };
  },

  paymentSuccess(name: string, planName: string, amount: string): EmailOptions {
    return {
      to: '',
      subject: `💳 Pago recibido - Plan ${planName}`,
      htmlBody: baseTemplate(`
        <h2 style="color: #1f2937; margin-top: 0;">¡Pago confirmado, ${name}! ✨</h2>
        <p style="color: #4b5563; line-height: 1.6;">Tu pago de <strong>$${amount}</strong> para el plan <strong>${planName}</strong> fue procesado correctamente.</p>
        <p style="color: #4b5563; line-height: 1.6;">Tu equipo de agentes IA está siendo configurado. Recibirás un email con los próximos pasos de onboarding dentro de las próximas horas.</p>
        <div style="text-align: center; margin: 24px 0;">
          <a href="${process.env.APP_URL}/dashboard" style="background: #2563EB; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600;">Ir al Dashboard</a>
        </div>
      `),
      tag: 'payment-success',
    };
  },
};
