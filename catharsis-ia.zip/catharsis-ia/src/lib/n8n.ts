const N8N_BASE_URL = process.env.N8N_WEBHOOK_URL || 'https://auto.catharsis-ia.com/webhook';
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET_INTERNAL || '';

export type N8NWebhook =
  | 'lead-created'
  | 'demo-started'
  | 'demo-completed'
  | 'reservation-created'
  | 'reservation-updated'
  | 'payment-succeeded'
  | 'payment-failed'
  | 'onboarding-submitted'
  | 'usage-alert'
  | 'no-show';

export async function triggerN8N(webhook: N8NWebhook, data: Record<string, unknown>): Promise<boolean> {
  try {
    const url = `${N8N_BASE_URL}/${webhook}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Webhook-Secret': WEBHOOK_SECRET,
      },
      body: JSON.stringify({
        ...data,
        _timestamp: new Date().toISOString(),
        _source: 'catharsis-ia-app',
      }),
      signal: AbortSignal.timeout(10000), // 10s timeout
    });

    if (!response.ok) {
      console.error(`[n8n] Webhook ${webhook} failed: ${response.status} ${response.statusText}`);
      return false;
    }

    return true;
  } catch (error) {
    console.error(`[n8n] Webhook ${webhook} error:`, error);
    return false;
  }
}

// Convenience wrappers
export const n8n = {
  leadCreated: (data: Record<string, unknown>) => triggerN8N('lead-created', data),
  demoStarted: (data: Record<string, unknown>) => triggerN8N('demo-started', data),
  demoCompleted: (data: Record<string, unknown>) => triggerN8N('demo-completed', data),
  reservationCreated: (data: Record<string, unknown>) => triggerN8N('reservation-created', data),
  reservationUpdated: (data: Record<string, unknown>) => triggerN8N('reservation-updated', data),
  paymentSucceeded: (data: Record<string, unknown>) => triggerN8N('payment-succeeded', data),
  paymentFailed: (data: Record<string, unknown>) => triggerN8N('payment-failed', data),
  onboardingSubmitted: (data: Record<string, unknown>) => triggerN8N('onboarding-submitted', data),
  usageAlert: (data: Record<string, unknown>) => triggerN8N('usage-alert', data),
  noShow: (data: Record<string, unknown>) => triggerN8N('no-show', data),
};
