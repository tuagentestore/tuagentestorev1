import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { AuthProvider } from "@/components/layout/AuthProvider";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "Catharsis IA – Agentes IA para tu negocio",
    template: "%s | Catharsis IA",
  },
  description: "Marketplace de agentes de inteligencia artificial. Probá, reservá e implementá automatizaciones que trabajan 24/7 para tu negocio.",
  keywords: ["agentes IA", "automatización", "inteligencia artificial", "chatbot", "marketing automation", "ventas IA"],
  openGraph: {
    title: "Catharsis IA – Agentes IA para tu negocio",
    description: "Marketplace de agentes IA listos para automatizar tu negocio. Demo gratis.",
    type: "website",
    locale: "es_AR",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>
        <AuthProvider>
          <div className="min-h-screen bg-background flex flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
        </AuthProvider>
      </body>
    </html>
  );
}
