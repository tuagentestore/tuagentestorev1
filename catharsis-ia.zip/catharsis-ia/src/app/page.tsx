'use client';

import React from 'react';
import Link from 'next/link';
import { Bot, Zap, Shield, BarChart3, Clock, ArrowRight, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const features = [
  { icon: Zap, title: 'Automatización 24/7', description: 'Tus agentes trabajan mientras dormís. Sin pausas, sin errores humanos.' },
  { icon: Shield, title: 'Implementación en 48h', description: 'De la compra al agente activo en dos días. Onboarding personalizado incluido.' },
  { icon: BarChart3, title: 'Reportes Inteligentes', description: 'Dashboard en tiempo real con métricas, alertas y recomendaciones de optimización.' },
  { icon: Clock, title: 'ROI desde el Día 1', description: 'Ahorrá +20 horas semanales automatizando tareas repetitivas con IA.' },
];

const steps = [
  { number: '01', title: 'Explorá el Catálogo', description: 'Navegá por nuestra colección de agentes IA especializados por industria.' },
  { number: '02', title: 'Probá el Demo Gratis', description: 'Interactuá con el agente en tiempo real. 3 mensajes para conocerlo.' },
  { number: '03', title: 'Reservá tu Agente', description: 'Completá tus datos y elegí tu plan. Te contactamos en 24h.' },
  { number: '04', title: 'Activación en 48h', description: 'Onboarding, configuración y tu agente IA trabajando para vos.' },
];

const plans = [
  {
    name: 'Starter',
    price: 49,
    setup: 299,
    features: ['1 agente IA activo', '1.000 acciones/mes', '3 integraciones', 'Soporte email (48h)', 'Dashboard básico'],
    popular: false,
  },
  {
    name: 'Pro',
    price: 199,
    setup: 599,
    features: ['Hasta 5 agentes IA', '10.000 acciones/mes', 'Integraciones ilimitadas', 'Soporte prioritario (12h)', 'Dashboard avanzado', 'API access', 'Onboarding personalizado'],
    popular: true,
  },
  {
    name: 'Enterprise',
    price: null,
    setup: null,
    features: ['Agentes ilimitados', 'Acciones ilimitadas', 'Account manager dedicado', 'SLA garantizado (4h)', 'Desarrollo custom', 'Training para equipo'],
    popular: false,
  },
];

export default function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-50" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-36">
          <div className="text-center max-w-4xl mx-auto">
            <Badge variant="outline" className="mb-6 text-sm px-4 py-1.5">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Marketplace de Agentes IA
            </Badge>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6">
              Automatizá tu negocio con{' '}
              <span className="text-gradient">Agentes IA</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto">
              Probá agentes inteligentes en vivo, reservá el que necesitás y tené tu automatización
              funcionando en 48 horas. Sin código, sin complicaciones.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/catalogo">
                <Button size="xl" className="w-full sm:w-auto">
                  Explorar Agentes <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Link href="#como-funciona">
                <Button variant="outline" size="xl" className="w-full sm:w-auto">
                  Cómo Funciona
                </Button>
              </Link>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">
              Demo gratuito · Sin tarjeta de crédito · Activación en 48h
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            ¿Por qué Catharsis IA?
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Agentes especializados que entienden tu industria y trabajan con tus herramientas.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, idx) => (
            <Card key={idx} className="border-border hover:border-primary/30 transition-all hover:shadow-custom group">
              <CardContent className="p-6">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="como-funciona" className="bg-muted/30 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Cómo Funciona</h2>
            <p className="text-muted-foreground text-lg">De la exploración al agente activo en 4 pasos simples.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, idx) => (
              <div key={idx} className="relative">
                <div className="text-5xl font-bold text-primary/10 mb-2">{step.number}</div>
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-muted-foreground text-sm">{step.description}</p>
                {idx < steps.length - 1 && (
                  <ArrowRight className="hidden lg:block absolute top-8 -right-4 w-6 h-6 text-primary/20" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="precios" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Planes y Precios</h2>
          <p className="text-muted-foreground text-lg">Elegí el plan que se adapte a tu negocio. Sin contratos largos.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, idx) => (
            <Card key={idx} className={`relative ${plan.popular ? 'border-primary shadow-custom-lg scale-105' : 'border-border'}`}>
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">Más Popular</Badge>
                </div>
              )}
              <CardContent className="p-8">
                <h3 className="text-xl font-bold mb-2">{plan.name}</h3>
                {plan.price !== null ? (
                  <div className="mb-1">
                    <span className="text-4xl font-bold">${plan.price}</span>
                    <span className="text-muted-foreground">/mes</span>
                  </div>
                ) : (
                  <div className="text-4xl font-bold mb-1">Personalizado</div>
                )}
                {plan.setup !== null && (
                  <p className="text-sm text-muted-foreground mb-6">+ ${plan.setup} setup único</p>
                )}
                {plan.setup === null && <p className="text-sm text-muted-foreground mb-6">Contactanos para cotización</p>}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/catalogo">
                  <Button className="w-full" variant={plan.popular ? 'default' : 'outline'}>
                    {plan.price !== null ? 'Empezar Ahora' : 'Contactar'}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Final CTA */}
      <section className="bg-muted/30 py-20">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            ¿Listo para automatizar tu negocio?
          </h2>
          <p className="text-muted-foreground text-lg mb-8">
            Probá cualquier agente gratis. Sin compromiso, sin tarjeta de crédito.
          </p>
          <Link href="/catalogo">
            <Button size="xl">
              Explorar Agentes <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
