'use client';

import React from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { Bot, Sparkles, Check, Book, Clock, Settings, LinkIcon, ArrowLeft, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { api, type AgentPublic } from '@/lib/api-client';
import { categoryColors, categoryLabels } from '@/lib/brand';

export default function AgentDetailPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [agent, setAgent] = React.useState<AgentPublic | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [openFaq, setOpenFaq] = React.useState<number | null>(null);

  React.useEffect(() => {
    if (slug) {
      api.agents.get(slug).then(setAgent).catch(console.error).finally(() => setLoading(false));
    }
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="h-96 bg-card border border-border rounded-xl animate-pulse" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Agente no encontrado</h1>
        <Link href="/catalogo"><Button variant="outline">Volver al Catálogo</Button></Link>
      </div>
    );
  }

  const catColor = categoryColors[agent.category] || '';
  const catLabel = categoryLabels[agent.category] || agent.category;
  const faqs = (agent.faqs || []) as { question: string; answer: string }[];
  const capabilities = (agent.capabilities || []) as string[];
  const integrations = (agent.integrations || []) as string[];
  const automatedTasks = (agent.automatedTasks || []) as string[];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Back */}
      <Link href="/catalogo" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-8">
        <ArrowLeft className="w-4 h-4" /> Volver al catálogo
      </Link>

      {/* Header */}
      <div className="flex flex-col md:flex-row gap-8 mb-12">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
              <Bot className="w-7 h-7 text-primary" />
            </div>
            <div>
              <Badge className={catColor}>{catLabel}</Badge>
              {agent.featured && <Badge className="ml-2 bg-amber-500/10 text-amber-500 border-amber-500/20">Destacado</Badge>}
            </div>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-3">{agent.name}</h1>
          <p className="text-lg text-muted-foreground mb-6">{agent.tagline}</p>
          <p className="text-foreground leading-relaxed">{agent.longDescription || agent.description}</p>
        </div>

        {/* CTA Card */}
        <div className="md:w-80 flex-shrink-0">
          <Card className="border-primary/20 shadow-custom sticky top-24">
            <CardContent className="p-6">
              {agent.pricingBasic && (
                <div className="mb-4">
                  <p className="text-sm text-muted-foreground">Desde</p>
                  <p className="text-3xl font-bold">${agent.pricingBasic}<span className="text-lg text-muted-foreground">/mes</span></p>
                </div>
              )}
              <div className="space-y-3 mb-6">
                {agent.demoAvailable && (
                  <Link href={`/demo/${agent.slug}`} className="block">
                    <Button className="w-full gap-2">
                      <Sparkles className="w-4 h-4" /> Probar Demo Gratis
                    </Button>
                  </Link>
                )}
                <Link href={`/demo/${agent.slug}?reserve=true`} className="block">
                  <Button variant="outline" className="w-full">Reservar Agente</Button>
                </Link>
              </div>
              {agent.installTime && (
                <p className="text-xs text-muted-foreground text-center">
                  <Clock className="w-3 h-3 inline mr-1" />
                  Activación en {agent.installTime}
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Capabilities */}
      {capabilities.length > 0 && (
        <Card className="mb-8">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold mb-4">Capacidades</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {capabilities.map((cap, idx) => (
                <div key={idx} className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-primary flex-shrink-0" />
                  <span className="text-sm">{cap}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Integrations */}
      {integrations.length > 0 && (
        <Card className="mb-8">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <LinkIcon className="w-5 h-5 text-primary" /> Integraciones
            </h2>
            <div className="flex flex-wrap gap-2">
              {integrations.map((int, idx) => (
                <Badge key={idx} variant="outline" className="px-3 py-1">{int}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Documentation */}
      <Card className="mb-8">
        <CardContent className="p-6 md:p-8">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Book className="w-5 h-5 text-primary" /> Documentación
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {agent.howItWorks && (
              <div className="bg-muted/30 rounded-lg p-4 border border-border">
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Book className="w-4 h-4 text-primary" /> Cómo Funciona</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">{agent.howItWorks}</p>
              </div>
            )}
            {agent.implementation && (
              <div className="bg-muted/30 rounded-lg p-4 border border-border">
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Settings className="w-4 h-4 text-primary" /> Implementación</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">{agent.implementation}</p>
              </div>
            )}
            {agent.requirements && (
              <div className="bg-muted/30 rounded-lg p-4 border border-border">
                <h3 className="font-semibold mb-2 flex items-center gap-2"><LinkIcon className="w-4 h-4 text-primary" /> Requerimientos</h3>
                <p className="text-sm text-muted-foreground whitespace-pre-line">{agent.requirements}</p>
              </div>
            )}
            {agent.installTime && (
              <div className="bg-muted/30 rounded-lg p-4 border border-border">
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Clock className="w-4 h-4 text-primary" /> Tiempo de Instalación</h3>
                <p className="text-sm text-muted-foreground">{agent.installTime} desde la confirmación del pago.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Automated Tasks */}
      {automatedTasks.length > 0 && (
        <Card className="mb-8">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold mb-4">Tareas Automatizadas</h2>
            <ul className="space-y-2">
              {automatedTasks.map((task, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <div className="w-5 h-5 bg-primary/10 rounded flex items-center justify-center mt-0.5 flex-shrink-0">
                    <Check className="w-3 h-3 text-primary" />
                  </div>
                  <span className="text-sm">{task}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Pricing */}
      {(agent.pricingBasic || agent.pricingPro || agent.pricingEnterprise) && (
        <Card className="mb-8">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold mb-6">Planes para este Agente</h2>
            <div className="grid sm:grid-cols-3 gap-4">
              {agent.pricingBasic && (
                <div className="border border-border rounded-lg p-4 text-center">
                  <p className="font-semibold mb-1">Básico</p>
                  <p className="text-2xl font-bold">${agent.pricingBasic}<span className="text-sm text-muted-foreground">/mes</span></p>
                </div>
              )}
              {agent.pricingPro && (
                <div className="border border-primary/30 rounded-lg p-4 text-center bg-primary/5">
                  <p className="font-semibold mb-1">Pro</p>
                  <p className="text-2xl font-bold text-primary">${agent.pricingPro}<span className="text-sm text-muted-foreground">/mes</span></p>
                </div>
              )}
              {agent.pricingEnterprise && (
                <div className="border border-border rounded-lg p-4 text-center">
                  <p className="font-semibold mb-1">Enterprise</p>
                  <p className="text-2xl font-bold">${agent.pricingEnterprise}<span className="text-sm text-muted-foreground">/mes</span></p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* FAQs */}
      {faqs.length > 0 && (
        <Card className="mb-8">
          <CardContent className="p-6 md:p-8">
            <h2 className="text-xl font-bold mb-4">Preguntas Frecuentes</h2>
            <div className="space-y-2">
              {faqs.map((faq, idx) => (
                <div key={idx} className="border border-border rounded-lg">
                  <button
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full flex items-center justify-between p-4 text-left"
                  >
                    <span className="font-medium text-sm">{faq.question}</span>
                    {openFaq === idx ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                  </button>
                  {openFaq === idx && (
                    <div className="px-4 pb-4">
                      <p className="text-sm text-muted-foreground">{faq.answer}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
