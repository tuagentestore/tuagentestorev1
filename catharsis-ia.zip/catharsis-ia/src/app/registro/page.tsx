'use client';

import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Bot, Loader2, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input, Label, SimpleSelect } from '@/components/ui/input';
import { useAuthStore } from '@/hooks/useAuth';
import { BRAND, industryOptions } from '@/lib/brand';

export default function RegistroPage() {
  const router = useRouter();
  const { register, loading, error, clearError, user } = useAuthStore();
  const [form, setForm] = React.useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    company: '',
    phone: '',
    industry: '',
  });
  const [showPassword, setShowPassword] = React.useState(false);
  const [localError, setLocalError] = React.useState('');

  React.useEffect(() => {
    if (user) router.push('/dashboard');
  }, [user, router]);

  React.useEffect(() => {
    clearError();
    setLocalError('');
  }, [form, clearError]);

  const updateField = (field: string, value: string) => {
    setForm(f => ({ ...f, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalError('');

    if (form.password.length < 8) {
      setLocalError('La contraseña debe tener al menos 8 caracteres.');
      return;
    }
    if (form.password !== form.confirmPassword) {
      setLocalError('Las contraseñas no coinciden.');
      return;
    }

    const success = await register({
      fullName: form.fullName,
      email: form.email,
      password: form.password,
      company: form.company || undefined,
      phone: form.phone || undefined,
      industry: form.industry || undefined,
    });
    if (success) router.push('/dashboard');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-12">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <Link href="/" className="inline-flex items-center gap-2 justify-center mb-4">
            <Bot className="w-8 h-8 text-primary" />
            <span className="font-bold text-xl">{BRAND.name}</span>
          </Link>
          <CardTitle className="text-2xl">Crear Cuenta</CardTitle>
          <p className="text-sm text-muted-foreground">
            Registrate para acceder a nuestros agentes IA
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label>Nombre completo *</Label>
                <Input
                  required
                  placeholder="Juan Pérez"
                  value={form.fullName}
                  onChange={e => updateField('fullName', e.target.value)}
                  autoComplete="name"
                />
              </div>
              <div>
                <Label>Email *</Label>
                <Input
                  type="email"
                  required
                  placeholder="tu@email.com"
                  value={form.email}
                  onChange={e => updateField('email', e.target.value)}
                  autoComplete="email"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label>Contraseña *</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Min. 8 caracteres"
                    value={form.password}
                    onChange={e => updateField('password', e.target.value)}
                    autoComplete="new-password"
                    className="pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div>
                <Label>Confirmar contraseña *</Label>
                <Input
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="Repetí la contraseña"
                  value={form.confirmPassword}
                  onChange={e => updateField('confirmPassword', e.target.value)}
                  autoComplete="new-password"
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <Label>Empresa</Label>
                <Input
                  placeholder="Mi Empresa SRL"
                  value={form.company}
                  onChange={e => updateField('company', e.target.value)}
                />
              </div>
              <div>
                <Label>Teléfono</Label>
                <Input
                  placeholder="+54 11 1234-5678"
                  value={form.phone}
                  onChange={e => updateField('phone', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label>Industria</Label>
              <SimpleSelect
                value={form.industry}
                onChange={e => updateField('industry', e.target.value)}
              >
                <option value="">Seleccioná una industria</option>
                {industryOptions.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </SimpleSelect>
            </div>

            {(localError || error) && (
              <p className="text-sm text-destructive">{localError || error}</p>
            )}

            <Button type="submit" disabled={loading} className="w-full gap-2">
              {loading && <Loader2 className="w-4 h-4 animate-spin" />}
              Crear Cuenta
            </Button>
          </form>

          <div className="mt-6 text-center text-sm">
            <p className="text-muted-foreground">
              ¿Ya tenés cuenta?{' '}
              <Link href="/login" className="text-primary hover:underline font-medium">
                Iniciar sesión
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
