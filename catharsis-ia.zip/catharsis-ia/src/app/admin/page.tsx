'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Bot, Users, CalendarCheck, DollarSign, Loader2, Eye, ChevronDown,
  BarChart3, Clock, CheckCircle, AlertCircle, ArrowLeft, MessageSquare,
  TrendingUp, Activity
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input, SimpleSelect } from '@/components/ui/input';
import { useAuthStore } from '@/hooks/useAuth';
import { api } from '@/lib/api-client';

interface DashboardStats {
  totalReservations: number;
  pendingReservations: number;
  totalDemos: number;
  conversionRate: number;
  recentReservations: Reservation[];
}

interface Reservation {
  id: string;
  userName: string;
  userEmail: string;
  company: string | null;
  phone: string | null;
  industry: string | null;
  useCase: string;
  planInterest: string | null;
  status: string;
  agentId: string;
  agent?: { name: string; slug: string };
  createdAt: string;
}

const statusLabels: Record<string, string> = {
  pending: 'Pendiente',
  contacted: 'Contactado',
  qualified: 'Calificado',
  demo_scheduled: 'Demo Agendada',
  validated: 'Validado',
  paid: 'Pagado',
  implementing: 'Implementando',
  active: 'Activo',
  cancelled: 'Cancelado',
};

const statusColors: Record<string, string> = {
  pending: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  contacted: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  qualified: 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
  demo_scheduled: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
  validated: 'bg-cyan-500/10 text-cyan-500 border-cyan-500/20',
  paid: 'bg-green-500/10 text-green-500 border-green-500/20',
  implementing: 'bg-teal-500/10 text-teal-500 border-teal-500/20',
  active: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  cancelled: 'bg-red-500/10 text-red-500 border-red-500/20',
};

const nextStatuses: Record<string, string[]> = {
  pending: ['contacted', 'cancelled'],
  contacted: ['qualified', 'cancelled'],
  qualified: ['demo_scheduled', 'cancelled'],
  demo_scheduled: ['validated', 'cancelled'],
  validated: ['paid', 'cancelled'],
  paid: ['implementing', 'cancelled'],
  implementing: ['active', 'cancelled'],
  active: [],
  cancelled: ['pending'],
};

export default function AdminPage() {
  const router = useRouter();
  const { user, loading: authLoading } = useAuthStore();
  const [stats, setStats] = React.useState<DashboardStats | null>(null);
  const [reservations, setReservations] = React.useState<Reservation[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [statusFilter, setStatusFilter] = React.useState('');
  const [updatingId, setUpdatingId] = React.useState<string | null>(null);
  const [expandedId, setExpandedId] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    } else if (!authLoading && user && user.role !== 'admin' && user.role !== 'superadmin') {
      router.push('/dashboard');
    }
  }, [user, authLoading, router]);

  React.useEffect(() => {
    if (user && (user.role === 'admin' || user.role === 'superadmin')) {
      loadData();
    }
  }, [user, statusFilter]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [dashData, resData] = await Promise.all([
        api.admin.dashboard(),
        api.reservations.list(statusFilter || undefined),
      ]);
      setStats(dashData);
      setReservations(resData);
    } catch (err) {
      console.error('Error loading admin data', err);
    } finally {
      setLoading(false);
    }
  };

  const updateReservation = async (id: string, status: string) => {
    setUpdatingId(id);
    try {
      await api.reservations.update(id, { status });
      await loadData();
    } catch (err) {
      console.error('Error updating reservation', err);
    } finally {
      setUpdatingId(null);
    }
  };

  if (authLoading || !user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Link href="/dashboard" className="text-muted-foreground hover:text-primary">
              <ArrowLeft className="w-4 h-4" />
            </Link>
            <h1 className="text-2xl font-bold">Panel de Administración</h1>
          </div>
          <p className="text-muted-foreground">Gestión de reservas, demos y métricas</p>
        </div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                  <CalendarCheck className="w-5 h-5 text-blue-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalReservations}</p>
                  <p className="text-sm text-muted-foreground">Reservas Totales</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-amber-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.pendingReservations}</p>
                  <p className="text-sm text-muted-foreground">Pendientes</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center">
                  <MessageSquare className="w-5 h-5 text-purple-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.totalDemos}</p>
                  <p className="text-sm text-muted-foreground">Demos Realizadas</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{stats.conversionRate}%</p>
                  <p className="text-sm text-muted-foreground">Conversión</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Reservations */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <CardTitle className="flex items-center gap-2">
              <CalendarCheck className="w-5 h-5 text-primary" /> Reservas
            </CardTitle>
            <SimpleSelect
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value)}
              className="w-48"
            >
              <option value="">Todos los estados</option>
              {Object.entries(statusLabels).map(([key, label]) => (
                <option key={key} value={key}>{label}</option>
              ))}
            </SimpleSelect>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-20 bg-muted rounded-lg animate-pulse" />
              ))}
            </div>
          ) : reservations.length === 0 ? (
            <div className="text-center py-12">
              <CalendarCheck className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold mb-1">No hay reservas</h3>
              <p className="text-sm text-muted-foreground">
                {statusFilter ? 'No hay reservas con este estado.' : 'Todavía no se recibieron reservas.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {reservations.map(res => (
                <div key={res.id} className="border border-border rounded-lg overflow-hidden">
                  {/* Row */}
                  <button
                    onClick={() => setExpandedId(expandedId === res.id ? null : res.id)}
                    className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <Users className="w-5 h-5 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <p className="font-medium truncate">{res.userName}</p>
                        <p className="text-sm text-muted-foreground truncate">
                          {res.userEmail} {res.company && `· ${res.company}`}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0 ml-4">
                      <Badge className={statusColors[res.status] || ''}>
                        {statusLabels[res.status] || res.status}
                      </Badge>
                      <span className="text-xs text-muted-foreground hidden sm:block">
                        {new Date(res.createdAt).toLocaleDateString('es-AR')}
                      </span>
                      <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expandedId === res.id ? 'rotate-180' : ''}`} />
                    </div>
                  </button>

                  {/* Expanded detail */}
                  {expandedId === res.id && (
                    <div className="px-4 pb-4 border-t border-border pt-4">
                      <div className="grid sm:grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Agente</p>
                          <p className="text-sm font-medium">{res.agent?.name || 'N/A'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Teléfono</p>
                          <p className="text-sm">{res.phone || 'No indicado'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Industria</p>
                          <p className="text-sm">{res.industry || 'No indicada'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground mb-1">Plan de interés</p>
                          <p className="text-sm">{res.planInterest || 'No indicado'}</p>
                        </div>
                        <div className="sm:col-span-2">
                          <p className="text-xs text-muted-foreground mb-1">Caso de uso</p>
                          <p className="text-sm">{res.useCase}</p>
                        </div>
                      </div>

                      {/* Status Actions */}
                      {nextStatuses[res.status] && nextStatuses[res.status].length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          <span className="text-xs text-muted-foreground self-center">Cambiar estado:</span>
                          {nextStatuses[res.status].map(ns => (
                            <Button
                              key={ns}
                              variant={ns === 'cancelled' ? 'destructive' : 'outline'}
                              size="sm"
                              disabled={updatingId === res.id}
                              onClick={() => updateReservation(res.id, ns)}
                              className="text-xs"
                            >
                              {updatingId === res.id ? (
                                <Loader2 className="w-3 h-3 animate-spin mr-1" />
                              ) : null}
                              {statusLabels[ns]}
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
