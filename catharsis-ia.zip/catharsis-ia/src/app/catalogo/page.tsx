'use client';

import React from 'react';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import AgentCard from '@/components/agents/AgentCard';
import { api, type AgentPublic } from '@/lib/api-client';
import { categoryLabels, categoryColors } from '@/lib/brand';

const categories = ['Todos', ...Object.keys(categoryLabels)];

export default function CatalogPage() {
  const [agents, setAgents] = React.useState<AgentPublic[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState('');
  const [selectedCategory, setSelectedCategory] = React.useState('Todos');

  React.useEffect(() => {
    api.agents.list().then(setAgents).catch(console.error).finally(() => setLoading(false));
  }, []);

  const filtered = agents.filter((agent) => {
    const matchesSearch = !search || 
      agent.name.toLowerCase().includes(search.toLowerCase()) ||
      agent.tagline.toLowerCase().includes(search.toLowerCase()) ||
      agent.description.toLowerCase().includes(search.toLowerCase());
    
    const matchesCategory = selectedCategory === 'Todos' || agent.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold mb-4">Catálogo de Agentes IA</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Explorá nuestra colección de agentes inteligentes. Cada uno diseñado para resolver problemas específicos de tu negocio.
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar agentes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            const color = cat !== 'Todos' ? categoryColors[cat] : '';
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-custom'
                    : 'bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80'
                }`}
              >
                {categoryLabels[cat] || cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Results */}
      {loading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-72 bg-card border border-border rounded-xl animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <SlidersHorizontal className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">No se encontraron agentes</h3>
          <p className="text-muted-foreground">Probá ajustando los filtros o buscando con otros términos.</p>
        </div>
      ) : (
        <>
          <p className="text-sm text-muted-foreground mb-6">{filtered.length} agente{filtered.length !== 1 ? 's' : ''} encontrado{filtered.length !== 1 ? 's' : ''}</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((agent) => (
              <AgentCard key={agent.id} agent={agent} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
