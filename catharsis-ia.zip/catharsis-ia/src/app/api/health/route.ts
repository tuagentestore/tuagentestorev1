import { db } from '@/lib/db';
import { apiSuccess, apiError } from '@/lib/api-helpers';

export async function GET() {
  try {
    // Check DB connection
    await db.$queryRaw`SELECT 1`;

    return apiSuccess({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || '1.0.0',
      environment: process.env.NODE_ENV,
    });
  } catch (error) {
    return apiError('Database connection failed', 503);
  }
}
