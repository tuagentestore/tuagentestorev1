import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { db } from '@/lib/db';
import { logWebhook } from '@/lib/api-helpers';
import { n8n } from '@/lib/n8n';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-11-20.acacia' });
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature')!;

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, webhookSecret);
  } catch (err) {
    console.error('[stripe] Webhook signature verification failed');
    await logWebhook('stripe', 'signature_failed', {}, 'failed', 'Invalid signature');
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  await logWebhook('stripe', event.type, event.data.object);

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        // Handle successful checkout
        if (session.subscription) {
          await handleSubscriptionCreated(session);
        }
        break;
      }
      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentSucceeded(invoice);
        break;
      }
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }
      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdated(sub);
        break;
      }
      case 'customer.subscription.deleted': {
        const sub = event.data.object as Stripe.Subscription;
        await handleSubscriptionDeleted(sub);
        break;
      }
    }

    await logWebhook('stripe', event.type, event.data.object, 'processed');
  } catch (error) {
    console.error(`[stripe] Error processing ${event.type}:`, error);
    await logWebhook('stripe', event.type, event.data.object, 'failed', String(error));
  }

  return NextResponse.json({ received: true });
}

async function handleSubscriptionCreated(session: Stripe.Checkout.Session) {
  // Find subscription by stripe ID and update
  const tenantId = session.metadata?.tenantId;
  if (!tenantId) return;

  const subscription = await db.subscription.findUnique({ where: { tenantId } });
  if (subscription) {
    await db.subscription.update({
      where: { id: subscription.id },
      data: { stripeSubscriptionId: session.subscription as string, status: 'active' },
    });
  }
}

async function handlePaymentSucceeded(invoice: Stripe.Invoice) {
  const subId = invoice.subscription as string;
  const subscription = await db.subscription.findFirst({
    where: { stripeSubscriptionId: subId },
    include: { tenant: true, plan: true },
  });

  if (!subscription) return;

  await db.payment.create({
    data: {
      subscriptionId: subscription.id,
      gateway: 'stripe',
      externalId: invoice.id,
      amount: invoice.amount_paid / 100,
      currency: invoice.currency.toUpperCase(),
      status: 'succeeded',
      paidAt: new Date(),
    },
  });

  n8n.paymentSucceeded({
    subscriptionId: subscription.id,
    tenantId: subscription.tenantId,
    tenantName: subscription.tenant.name,
    planName: subscription.plan.name,
    amount: invoice.amount_paid / 100,
    currency: invoice.currency,
    gateway: 'stripe',
  }).catch(() => {});
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  const subId = invoice.subscription as string;
  const subscription = await db.subscription.findFirst({
    where: { stripeSubscriptionId: subId },
    include: { tenant: true, plan: true },
  });

  if (!subscription) return;

  await db.payment.create({
    data: {
      subscriptionId: subscription.id,
      gateway: 'stripe',
      externalId: invoice.id,
      amount: invoice.amount_due / 100,
      currency: invoice.currency.toUpperCase(),
      status: 'failed',
      failureReason: 'Payment method declined',
    },
  });

  await db.subscription.update({
    where: { id: subscription.id },
    data: { status: 'past_due' },
  });

  n8n.paymentFailed({
    subscriptionId: subscription.id,
    tenantId: subscription.tenantId,
    email: subscription.tenant.email,
    planName: subscription.plan.name,
    attemptCount: invoice.attempt_count,
    gateway: 'stripe',
  }).catch(() => {});
}

async function handleSubscriptionUpdated(sub: Stripe.Subscription) {
  const subscription = await db.subscription.findFirst({
    where: { stripeSubscriptionId: sub.id },
  });
  if (!subscription) return;

  await db.subscription.update({
    where: { id: subscription.id },
    data: {
      status: sub.status === 'active' ? 'active' : sub.status === 'past_due' ? 'past_due' : 'cancelled',
      currentPeriodStart: new Date(sub.current_period_start * 1000),
      currentPeriodEnd: new Date(sub.current_period_end * 1000),
    },
  });
}

async function handleSubscriptionDeleted(sub: Stripe.Subscription) {
  const subscription = await db.subscription.findFirst({
    where: { stripeSubscriptionId: sub.id },
  });
  if (!subscription) return;

  await db.subscription.update({
    where: { id: subscription.id },
    data: { status: 'cancelled', cancelledAt: new Date() },
  });
}
