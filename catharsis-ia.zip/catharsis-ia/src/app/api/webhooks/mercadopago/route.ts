import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { logWebhook } from '@/lib/api-helpers';
import { n8n } from '@/lib/n8n';

const MP_ACCESS_TOKEN = process.env.MP_ACCESS_TOKEN!;

export async function POST(req: NextRequest) {
  const body = await req.json();
  
  await logWebhook('mercadopago', body.type || 'unknown', body);

  try {
    if (body.type === 'payment') {
      const paymentId = body.data?.id;
      if (!paymentId) return NextResponse.json({ ok: true });

      // Fetch payment details from MP API
      const mpResponse = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: { Authorization: `Bearer ${MP_ACCESS_TOKEN}` },
      });
      const mpPayment = await mpResponse.json();

      if (mpPayment.status === 'approved') {
        const tenantId = mpPayment.metadata?.tenant_id;
        if (!tenantId) return NextResponse.json({ ok: true });

        const subscription = await db.subscription.findUnique({
          where: { tenantId },
          include: { tenant: true, plan: true },
        });
        
        if (subscription) {
          await db.payment.create({
            data: {
              subscriptionId: subscription.id,
              gateway: 'mercadopago',
              externalId: String(paymentId),
              amount: mpPayment.transaction_amount,
              currency: mpPayment.currency_id || 'ARS',
              status: 'succeeded',
              paymentMethod: mpPayment.payment_method_id,
              paidAt: new Date(),
            },
          });

          await db.subscription.update({
            where: { id: subscription.id },
            data: { status: 'active' },
          });

          n8n.paymentSucceeded({
            subscriptionId: subscription.id,
            tenantId,
            tenantName: subscription.tenant.name,
            planName: subscription.plan.name,
            amount: mpPayment.transaction_amount,
            currency: mpPayment.currency_id,
            gateway: 'mercadopago',
          }).catch(() => {});
        }
      } else if (mpPayment.status === 'rejected') {
        const tenantId = mpPayment.metadata?.tenant_id;
        if (tenantId) {
          const subscription = await db.subscription.findUnique({
            where: { tenantId },
            include: { tenant: true, plan: true },
          });
          
          if (subscription) {
            await db.payment.create({
              data: {
                subscriptionId: subscription.id,
                gateway: 'mercadopago',
                externalId: String(paymentId),
                amount: mpPayment.transaction_amount,
                currency: mpPayment.currency_id || 'ARS',
                status: 'failed',
                failureReason: mpPayment.status_detail,
              },
            });

            n8n.paymentFailed({
              subscriptionId: subscription.id,
              tenantId,
              email: subscription.tenant.email,
              planName: subscription.plan.name,
              gateway: 'mercadopago',
              reason: mpPayment.status_detail,
            }).catch(() => {});
          }
        }
      }
    }

    await logWebhook('mercadopago', body.type || 'unknown', body, 'processed');
  } catch (error) {
    console.error('[mercadopago] Webhook error:', error);
    await logWebhook('mercadopago', body.type || 'unknown', body, 'failed', String(error));
  }

  return NextResponse.json({ ok: true });
}
