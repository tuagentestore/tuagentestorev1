import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get('category');
  const featured = searchParams.get('featured');
  const status = searchParams.get('status') || 'active';

  const where: Record<string, unknown> = {};
  
  if (status !== 'all') {
    where.status = status;
  }
  if (category) {
    where.category = category;
  }
  if (featured === 'true') {
    where.featured = true;
  }

  const agents = await db.agent.findMany({
    where,
    select: {
      id: true,
      name: true,
      slug: true,
      tagline: true,
      description: true,
      category: true,
      capabilities: true,
      integrations: true,
      imageUrl: true,
      iconName: true,
      status: true,
      pricingBasic: true,
      pricingPro: true,
      pricingEnterprise: true,
      demoAvailable: true,
      featured: true,
    },
    orderBy: [{ featured: 'desc' }, { sortOrder: 'asc' }, { name: 'asc' }],
  });

  // Convert Decimal to number for JSON
  const result = agents.map(a => ({
    ...a,
    pricingBasic: a.pricingBasic ? Number(a.pricingBasic) : null,
    pricingPro: a.pricingPro ? Number(a.pricingPro) : null,
    pricingEnterprise: a.pricingEnterprise ? Number(a.pricingEnterprise) : null,
  }));

  return apiSuccess(result);
}
