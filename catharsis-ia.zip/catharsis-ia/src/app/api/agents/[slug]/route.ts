import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess, apiNotFound } from '@/lib/api-helpers';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;

  const agent = await db.agent.findUnique({
    where: { slug },
    select: {
      id: true,
      name: true,
      slug: true,
      tagline: true,
      description: true,
      longDescription: true,
      category: true,
      capabilities: true,
      integrations: true,
      imageUrl: true,
      iconName: true,
      status: true,
      pricingBasic: true,
      pricingPro: true,
      pricingEnterprise: true,
      demoAvailable: true,
      featured: true,
      faqs: true,
      howItWorks: true,
      implementation: true,
      installTime: true,
      requirements: true,
      automatedTasks: true,
    },
  });

  if (!agent) return apiNotFound('Agente no encontrado');

  return apiSuccess({
    ...agent,
    pricingBasic: agent.pricingBasic ? Number(agent.pricingBasic) : null,
    pricingPro: agent.pricingPro ? Number(agent.pricingPro) : null,
    pricingEnterprise: agent.pricingEnterprise ? Number(agent.pricingEnterprise) : null,
  });
}
