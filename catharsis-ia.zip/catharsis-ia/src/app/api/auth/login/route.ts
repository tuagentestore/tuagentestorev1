import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { verifyPassword, createSession } from '@/lib/auth';
import { apiSuccess, apiError, validateBody } from '@/lib/api-helpers';
import { loginSchema } from '@/lib/validations';

export async function POST(req: NextRequest) {
  const validation = await validateBody(req, loginSchema);
  if (validation.error) return validation.error;
  const { email, password } = validation.data;

  const user = await db.user.findUnique({
    where: { email: email.toLowerCase() },
    select: {
      id: true,
      email: true,
      passwordHash: true,
      fullName: true,
      role: true,
      tenantId: true,
      avatarUrl: true,
      status: true,
    },
  });

  if (!user) {
    return apiError('Email o contraseña incorrectos', 401);
  }

  if (user.status !== 'active') {
    return apiError('Tu cuenta está desactivada', 403);
  }

  const passwordValid = await verifyPassword(password, user.passwordHash);
  if (!passwordValid) {
    return apiError('Email o contraseña incorrectos', 401);
  }

  const session = await createSession(user.id, req);

  const response = apiSuccess({
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      tenantId: user.tenantId,
      avatarUrl: user.avatarUrl,
    },
    accessToken: session.accessToken,
    refreshToken: session.refreshToken,
  });

  response.cookies.set('access_token', session.accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60,
    path: '/',
  });

  return response;
}
