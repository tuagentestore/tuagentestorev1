import { NextRequest } from 'next/server';
import { revokeSession } from '@/lib/auth';
import { apiSuccess } from '@/lib/api-helpers';
import { cookies } from 'next/headers';

export async function POST(req: NextRequest) {
  const cookieStore = await cookies();
  const token = cookieStore.get('access_token')?.value;
  const authHeader = req.headers.get('authorization');
  const bearerToken = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;

  const sessionToken = bearerToken || token;
  if (sessionToken) {
    await revokeSession(sessionToken);
  }

  const response = apiSuccess({ message: 'Sesión cerrada' });
  response.cookies.set('access_token', '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 0,
    path: '/',
  });

  return response;
}
