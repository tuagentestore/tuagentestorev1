import { NextRequest } from 'next/server';
import { refreshSession } from '@/lib/auth';
import { apiSuccess, apiError, validateBody } from '@/lib/api-helpers';
import { refreshSchema } from '@/lib/validations';

export async function POST(req: NextRequest) {
  const validation = await validateBody(req, refreshSchema);
  if (validation.error) return validation.error;

  const result = await refreshSession(validation.data.refreshToken, req);
  if (!result) {
    return apiError('Token de refresco inválido o expirado', 401);
  }

  const response = apiSuccess({
    accessToken: result.accessToken,
    refreshToken: result.refreshToken,
  });

  response.cookies.set('access_token', result.accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60,
    path: '/',
  });

  return response;
}
