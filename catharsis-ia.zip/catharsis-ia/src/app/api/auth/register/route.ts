import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, createSession } from '@/lib/auth';
import { apiSuccess, apiError, validateBody } from '@/lib/api-helpers';
import { registerSchema } from '@/lib/validations';
import { slugify } from '@/lib/utils';
import { n8n } from '@/lib/n8n';

export async function POST(req: NextRequest) {
  const validation = await validateBody(req, registerSchema);
  if (validation.error) return validation.error;
  const { email, password, fullName, phone, company } = validation.data;

  // Check existing user
  const existing = await db.user.findUnique({ where: { email: email.toLowerCase() } });
  if (existing) {
    return apiError('Ya existe una cuenta con este email', 409);
  }

  const passwordHash = await hashPassword(password);

  // Create tenant + user in transaction
  const result = await db.$transaction(async (tx) => {
    const tenant = await tx.tenant.create({
      data: {
        name: company || fullName,
        slug: slugify(company || fullName) + '-' + Date.now().toString(36),
        email: email.toLowerCase(),
        phone,
        company,
      },
    });

    const user = await tx.user.create({
      data: {
        email: email.toLowerCase(),
        passwordHash,
        fullName,
        phone,
        tenantId: tenant.id,
        role: 'admin',
        status: 'active',
      },
    });

    return { tenant, user };
  });

  // Create session
  const session = await createSession(result.user.id, req);

  // Trigger n8n lead workflow (fire-and-forget)
  n8n.leadCreated({
    email: result.user.email,
    name: fullName,
    company,
    phone,
    source: 'register',
  }).catch(() => {});

  // Set cookie
  const response = apiSuccess({
    user: {
      id: result.user.id,
      email: result.user.email,
      fullName: result.user.fullName,
      role: result.user.role,
      tenantId: result.user.tenantId,
      avatarUrl: null,
    },
    accessToken: session.accessToken,
    refreshToken: session.refreshToken,
  }, 201);

  response.cookies.set('access_token', session.accessToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 7 * 24 * 60 * 60, // 7 days
    path: '/',
  });

  return response;
}
