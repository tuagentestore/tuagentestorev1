import { NextRequest } from 'next/server';
import { getAuthFromRequest } from '@/lib/auth';
import { apiSuccess, apiUnauthorized } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  const user = await getAuthFromRequest(req);
  if (!user) return apiUnauthorized();
  return apiSuccess(user);
}
