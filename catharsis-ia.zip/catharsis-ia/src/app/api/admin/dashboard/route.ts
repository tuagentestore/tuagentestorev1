import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getAuthFromRequest, requireAdmin } from '@/lib/auth';
import { apiSuccess, handleAuthError } from '@/lib/api-helpers';

export async function GET(req: NextRequest) {
  try {
    const user = await getAuthFromRequest(req);
    requireAdmin(user);
  } catch (error) {
    return handleAuthError(error);
  }

  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

  const [
    totalReservations,
    pendingReservations,
    totalDemos,
    demosConverted,
    recentReservations,
    reservationsByStatus,
    demosLast30d,
  ] = await Promise.all([
    db.reservation.count(),
    db.reservation.count({ where: { status: 'pending' } }),
    db.demoSession.count(),
    db.demoSession.count({ where: { convertedToReservation: true } }),
    db.reservation.findMany({
      include: { agent: { select: { name: true, slug: true } } },
      orderBy: { createdAt: 'desc' },
      take: 10,
    }),
    db.reservation.groupBy({
      by: ['status'],
      _count: { id: true },
    }),
    db.demoSession.count({
      where: { createdAt: { gte: thirtyDaysAgo } },
    }),
  ]);

  const conversionRate = totalDemos > 0 
    ? Math.round((demosConverted / totalDemos) * 100 * 10) / 10 
    : 0;

  const statusCounts = Object.fromEntries(
    reservationsByStatus.map(s => [s.status, s._count.id])
  );

  return apiSuccess({
    totalReservations,
    pendingReservations,
    totalDemos,
    demosLast30d,
    demosConverted,
    conversionRate,
    statusCounts,
    recentReservations,
  });
}
