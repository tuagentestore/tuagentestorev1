import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { getAuthFromRequest, requireAdmin } from '@/lib/auth';
import { apiSuccess, apiError, apiNotFound, validateBody, handleAuthError } from '@/lib/api-helpers';
import { updateReservationSchema } from '@/lib/validations';
import { n8n } from '@/lib/n8n';

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  try {
    const user = await getAuthFromRequest(req);
    requireAdmin(user);
  } catch (error) {
    return handleAuthError(error);
  }

  const validation = await validateBody(req, updateReservationSchema);
  if (validation.error) return validation.error;
  const data = validation.data;

  const reservation = await db.reservation.findUnique({ where: { id } });
  if (!reservation) return apiNotFound('Reserva no encontrada');

  const updateData: Record<string, unknown> = {};
  if (data.adminNotes !== undefined) updateData.adminNotes = data.adminNotes;
  if (data.status) {
    updateData.status = data.status;
    // Set timestamps based on status
    const timestamps: Record<string, string> = {
      contacted: 'contactedAt',
      qualified: 'qualifiedAt',
      validated: 'validatedAt',
      paid: 'paidAt',
    };
    if (timestamps[data.status]) {
      updateData[timestamps[data.status]] = new Date();
    }
  }

  const updated = await db.reservation.update({
    where: { id },
    data: updateData,
    include: { agent: { select: { name: true } } },
  });

  // Trigger n8n
  if (data.status) {
    n8n.reservationUpdated({
      reservationId: id,
      oldStatus: reservation.status,
      newStatus: data.status,
      userName: reservation.userName,
      userEmail: reservation.userEmail,
      agentName: updated.agent.name,
    }).catch(() => {});
  }

  return apiSuccess(updated);
}
