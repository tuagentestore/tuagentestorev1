import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess, apiError, validateBody, checkRateLimit } from '@/lib/api-helpers';
import { getAuthFromRequest, requireAdmin } from '@/lib/auth';
import { createReservationSchema } from '@/lib/validations';
import { n8n } from '@/lib/n8n';

// POST - Create reservation (public)
export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(`reservation:${ip}`, 3, 300000)) {
    return apiError('Demasiadas solicitudes', 429);
  }

  const validation = await validateBody(req, createReservationSchema);
  if (validation.error) return validation.error;
  const data = validation.data;

  // Verify agent exists
  const agent = await db.agent.findUnique({
    where: { id: data.agentId },
    select: { id: true, name: true },
  });
  if (!agent) return apiError('Agente no encontrado', 404);

  const reservation = await db.reservation.create({
    data: {
      agentId: data.agentId,
      userName: data.userName,
      userEmail: data.userEmail.toLowerCase(),
      company: data.company,
      phone: data.phone,
      industry: data.industry,
      useCase: data.useCase,
      planInterest: data.planInterest || 'Básico',
      preferredDate: data.preferredDate ? new Date(data.preferredDate) : null,
      notes: data.notes,
      demoSessionId: data.demoSessionId,
      status: 'pending',
    },
  });

  // Mark demo as converted if provided
  if (data.demoSessionId) {
    await db.demoSession.update({
      where: { id: data.demoSessionId },
      data: { convertedToReservation: true },
    }).catch(() => {});
  }

  // Trigger n8n workflows
  n8n.reservationCreated({
    reservationId: reservation.id,
    agentId: data.agentId,
    agentName: agent.name,
    userName: data.userName,
    userEmail: data.userEmail,
    company: data.company,
    phone: data.phone,
    industry: data.industry,
    useCase: data.useCase,
    planInterest: data.planInterest,
    preferredDate: data.preferredDate,
  }).catch(() => {});

  // Also trigger lead created if new email
  n8n.leadCreated({
    email: data.userEmail,
    name: data.userName,
    company: data.company,
    phone: data.phone,
    source: 'reservation',
    agentName: agent.name,
  }).catch(() => {});

  return apiSuccess({ id: reservation.id }, 201);
}

// GET - List reservations (admin only)
export async function GET(req: NextRequest) {
  try {
    const user = await getAuthFromRequest(req);
    requireAdmin(user);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message === 'UNAUTHORIZED') return apiError('No autorizado', 401);
      if (error.message === 'FORBIDDEN') return apiError('Acceso denegado', 403);
    }
    return apiError('Error de autenticación', 401);
  }

  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');

  const where: Record<string, unknown> = {};
  if (status && status !== 'all') where.status = status;

  const [reservations, total] = await Promise.all([
    db.reservation.findMany({
      where,
      include: { agent: { select: { name: true, slug: true } } },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * limit,
      take: limit,
    }),
    db.reservation.count({ where }),
  ]);

  return apiSuccess({
    items: reservations,
    total,
    page,
    totalPages: Math.ceil(total / limit),
  });
}
