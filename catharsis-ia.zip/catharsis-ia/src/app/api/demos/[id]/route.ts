import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess, apiNotFound } from '@/lib/api-helpers';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  const demo = await db.demoSession.findUnique({
    where: { id },
    select: {
      id: true,
      agentId: true,
      messagesUsed: true,
      maxMessages: true,
      conversation: true,
      status: true,
    },
  });

  if (!demo) return apiNotFound('Sesión no encontrada');
  return apiSuccess(demo);
}
