import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess, apiError, apiNotFound, validateBody, checkRateLimit } from '@/lib/api-helpers';
import { demoMessageSchema } from '@/lib/validations';
import { demoChat } from '@/lib/openai';
import { n8n } from '@/lib/n8n';

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  // Rate limit
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(`demo:msg:${ip}`, 10, 60000)) {
    return apiError('Demasiadas solicitudes', 429);
  }

  const validation = await validateBody(req, demoMessageSchema);
  if (validation.error) return validation.error;
  const { message } = validation.data;

  // Get demo session with agent
  const demo = await db.demoSession.findUnique({
    where: { id },
    include: { agent: { select: { name: true, demoPrompt: true } } },
  });

  if (!demo) return apiNotFound('Sesión de demo no encontrada');
  if (demo.status !== 'active') return apiError('Esta sesión de demo ya terminó', 400);
  if (demo.messagesUsed >= demo.maxMessages) {
    return apiError('Llegaste al límite de mensajes del demo. ¡Reservá para conocer más!', 400);
  }

  const systemPrompt = demo.agent.demoPrompt || 
    `Eres ${demo.agent.name} de Catharsis IA. Respondé de forma útil y concisa en español. Limita respuestas a 150 palabras.`;

  const conversation = (demo.conversation as { role: string; content: string }[]) || [];

  // Call OpenAI
  let reply: string;
  try {
    reply = await demoChat(systemPrompt, conversation, message);
  } catch (error) {
    console.error('[demo] OpenAI error:', error);
    return apiError('Error al generar respuesta. Intentá de nuevo.', 500);
  }

  // Update conversation
  const newConversation = [
    ...conversation,
    { role: 'user', content: message, timestamp: new Date().toISOString() },
    { role: 'assistant', content: reply, timestamp: new Date().toISOString() },
  ];

  const newMessagesUsed = demo.messagesUsed + 1;
  const newStatus = newMessagesUsed >= demo.maxMessages ? 'completed' : 'active';

  await db.demoSession.update({
    where: { id },
    data: {
      messagesUsed: newMessagesUsed,
      conversation: newConversation,
      status: newStatus as any,
    },
  });

  // If demo completed, trigger n8n
  if (newStatus === 'completed') {
    n8n.demoCompleted({
      demoId: id,
      agentId: demo.agentId,
      agentName: demo.agent.name,
      visitorEmail: demo.visitorEmail,
      visitorName: demo.visitorName,
      messagesUsed: newMessagesUsed,
      conversation: newConversation,
    }).catch(() => {});
  }

  return apiSuccess({
    reply,
    messagesUsed: newMessagesUsed,
    maxMessages: demo.maxMessages,
    status: newStatus,
  });
}
