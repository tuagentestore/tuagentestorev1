import { NextRequest } from 'next/server';
import { db } from '@/lib/db';
import { apiSuccess, apiError, apiNotFound, validateBody, checkRateLimit } from '@/lib/api-helpers';
import { createDemoSchema } from '@/lib/validations';
import { n8n } from '@/lib/n8n';

export async function POST(req: NextRequest) {
  // Rate limit: 5 demo creations per IP per minute
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  if (!checkRateLimit(`demo:create:${ip}`, 5, 60000)) {
    return apiError('Demasiadas solicitudes. Intentá de nuevo en un momento.', 429);
  }

  const validation = await validateBody(req, createDemoSchema);
  if (validation.error) return validation.error;
  const { agentId, visitorEmail, visitorName } = validation.data;

  // Verify agent exists and has demo
  const agent = await db.agent.findUnique({
    where: { id: agentId },
    select: { id: true, name: true, demoAvailable: true, demoPrompt: true },
  });

  if (!agent) return apiNotFound('Agente no encontrado');
  if (!agent.demoAvailable) return apiError('Este agente no tiene demo disponible', 400);

  const demo = await db.demoSession.create({
    data: {
      agentId,
      visitorEmail: visitorEmail?.toLowerCase(),
      visitorName,
      messagesUsed: 0,
      maxMessages: 3,
      conversation: [],
      status: 'active',
      ipAddress: ip,
    },
    select: {
      id: true,
      agentId: true,
      messagesUsed: true,
      maxMessages: true,
      conversation: true,
      status: true,
    },
  });

  // Fire n8n webhook (async)
  n8n.demoStarted({
    demoId: demo.id,
    agentId,
    agentName: agent.name,
    visitorEmail,
    visitorName,
    ip,
  }).catch(() => {});

  return apiSuccess(demo, 201);
}
