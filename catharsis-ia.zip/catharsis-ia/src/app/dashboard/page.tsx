'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Bot, Settings, Activity, CreditCard, LogOut, Loader2, Plus,
  BarChart3, Clock, CheckCircle, AlertCircle, Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useAuthStore } from '@/hooks/useAuth';
import { BRAND } from '@/lib/brand';

interface UserAgent {
  id: string;
  agent: { name: string; slug: string; category: string };
  status: string;
  actionsCount: number;
  lastActivity: string | null;
}

export default function DashboardPage() {
  const router = useRouter();
  const { user, loading: authLoading, logout } = useAuthStore();
  const [myAgents, setMyAgents] = React.useState<UserAgent[]>([]);
  const [stats, setStats] = React.useState({ totalActions: 0, activeAgents: 0, thisMonth: 0 });
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login');
    }
  }, [user, authLoading, router]);

  React.useEffect(() => {
    if (user) {
      // In production this would fetch from /api/user-agents and /api/usage
      setLoading(false);
    }
  }, [user]);

  if (authLoading || !user) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const statusBadge = (status: string) => {
    const map: Record<string, { variant: 'success' | 'warning' | 'outline' | 'destructive'; label: string }> = {
      active: { variant: 'success', label: 'Activo' },
      provisioning: { variant: 'warning', label: 'Configurando' },
      paused: { variant: 'outline', label: 'Pausado' },
      inactive: { variant: 'destructive', label: 'Inactivo' },
    };
    const s = map[status] || { variant: 'outline' as const, label: status };
    return <Badge variant={s.variant}>{s.label}</Badge>;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Bienvenido, {user.fullName}</p>
        </div>
        <div className="flex gap-2">
          <Link href="/catalogo">
            <Button variant="outline" className="gap-2">
              <Plus className="w-4 h-4" /> Agregar Agente
            </Button>
          </Link>
          {(user.role === 'admin' || user.role === 'superadmin') && (
            <Link href="/admin">
              <Button variant="outline" className="gap-2">
                <Settings className="w-4 h-4" /> Admin
              </Button>
            </Link>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.activeAgents}</p>
                <p className="text-sm text-muted-foreground">Agentes Activos</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/10 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.thisMonth.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Acciones este Mes</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalActions.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Acciones Totales</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* My Agents */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-primary" /> Mis Agentes
          </CardTitle>
        </CardHeader>
        <CardContent>
          {myAgents.length === 0 ? (
            <div className="text-center py-12">
              <Bot className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-semibold text-lg mb-2">No tenés agentes activos</h3>
              <p className="text-muted-foreground mb-4">
                Explorá nuestro catálogo y activá tu primer agente IA.
              </p>
              <Link href="/catalogo">
                <Button className="gap-2">
                  <Plus className="w-4 h-4" /> Explorar Catálogo
                </Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {myAgents.map(ua => (
                <div key={ua.id} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Bot className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">{ua.agent.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {ua.actionsCount.toLocaleString()} acciones
                        {ua.lastActivity && ` · Última actividad: ${new Date(ua.lastActivity).toLocaleDateString('es-AR')}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {statusBadge(ua.status)}
                    <Link href={`/dashboard/agente/${ua.agent.slug}`}>
                      <Button variant="ghost" size="sm">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Link href="/catalogo">
          <Card className="hover:border-primary/30 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex items-center gap-3">
              <Plus className="w-5 h-5 text-primary" />
              <span className="font-medium">Agregar Agente</span>
            </CardContent>
          </Card>
        </Link>
        <Card className="hover:border-primary/30 transition-colors cursor-pointer">
          <CardContent className="p-6 flex items-center gap-3">
            <Activity className="w-5 h-5 text-primary" />
            <span className="font-medium">Ver Actividad</span>
          </CardContent>
        </Card>
        <Card className="hover:border-primary/30 transition-colors cursor-pointer">
          <CardContent className="p-6 flex items-center gap-3">
            <CreditCard className="w-5 h-5 text-primary" />
            <span className="font-medium">Facturación</span>
          </CardContent>
        </Card>
        <button onClick={() => { logout(); router.push('/'); }} className="w-full text-left">
          <Card className="hover:border-destructive/30 transition-colors cursor-pointer h-full">
            <CardContent className="p-6 flex items-center gap-3">
              <LogOut className="w-5 h-5 text-destructive" />
              <span className="font-medium text-destructive">Cerrar Sesión</span>
            </CardContent>
          </Card>
        </button>
      </div>
    </div>
  );
}
