'use client';

import React from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Bot, Send, Sparkles, ArrowLeft, User, Loader2, MessageSquare, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input, Label, Textarea, SimpleSelect } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { api, type AgentPublic } from '@/lib/api-client';
import { categoryLabels } from '@/lib/brand';
import { BRAND, industryOptions, planInterestOptions } from '@/lib/brand';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function DemoPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const slug = params.slug as string;
  const showReserve = searchParams.get('reserve') === 'true';

  const [agent, setAgent] = React.useState<AgentPublic | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [activeTab, setActiveTab] = React.useState<'demo' | 'reserve'>(showReserve ? 'reserve' : 'demo');

  // Demo state
  const [demoSessionId, setDemoSessionId] = React.useState<string | null>(null);
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [inputMsg, setInputMsg] = React.useState('');
  const [sending, setSending] = React.useState(false);
  const [messagesUsed, setMessagesUsed] = React.useState(0);
  const [demoEmail, setDemoEmail] = React.useState('');
  const [demoName, setDemoName] = React.useState('');
  const [demoStarted, setDemoStarted] = React.useState(false);
  const [demoError, setDemoError] = React.useState('');

  // Reservation state
  const [resForm, setResForm] = React.useState({
    userName: '', userEmail: '', company: '', phone: '', industry: '', useCase: '', planInterest: '',
  });
  const [resLoading, setResLoading] = React.useState(false);
  const [resSuccess, setResSuccess] = React.useState(false);
  const [resError, setResError] = React.useState('');

  const messagesEndRef = React.useRef<HTMLDivElement>(null);
  const MAX_MESSAGES = 3;

  React.useEffect(() => {
    if (slug) {
      api.agents.get(slug).then(setAgent).catch(console.error).finally(() => setLoading(false));
    }
  }, [slug]);

  React.useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startDemo = async () => {
    if (!demoEmail || !demoName) {
      setDemoError('Completá tu nombre y email para probar la demo.');
      return;
    }
    setDemoError('');
    setSending(true);
    try {
      const session = await api.demos.create({
        agentSlug: slug,
        visitorEmail: demoEmail,
        visitorName: demoName,
      });
      setDemoSessionId(session.id);
      setDemoStarted(true);
      setMessages([{
        role: 'assistant',
        content: `¡Hola ${demoName}! Soy el ${agent?.name || 'agente'}. Tenés ${MAX_MESSAGES} mensajes para probarme. ¿En qué puedo ayudarte?`,
      }]);
    } catch (err: any) {
      setDemoError(err.message || 'Error al iniciar la demo');
    } finally {
      setSending(false);
    }
  };

  const sendMessage = async () => {
    if (!inputMsg.trim() || !demoSessionId || sending || messagesUsed >= MAX_MESSAGES) return;
    const userMsg = inputMsg.trim();
    setInputMsg('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setSending(true);

    try {
      const res = await api.demos.sendMessage(demoSessionId, { message: userMsg });
      setMessages(prev => [...prev, { role: 'assistant', content: res.reply }]);
      setMessagesUsed(res.messagesUsed);
    } catch (err: any) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Lo siento, ocurrió un error. Intentá de nuevo.' }]);
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const submitReservation = async (e: React.FormEvent) => {
    e.preventDefault();
    setResError('');
    setResLoading(true);
    try {
      await api.reservations.create({
        agentSlug: slug,
        ...resForm,
        demoSessionId: demoSessionId || undefined,
      });
      setResSuccess(true);
    } catch (err: any) {
      setResError(err.message || 'Error al enviar la reserva');
    } finally {
      setResLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="h-96 bg-card border border-border rounded-xl animate-pulse" />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Agente no encontrado</h1>
        <Link href="/catalogo"><Button variant="outline">Volver al Catálogo</Button></Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back */}
      <Link href={`/agente/${slug}`} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-6">
        <ArrowLeft className="w-4 h-4" /> Volver al agente
      </Link>

      {/* Header */}
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
          <Bot className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-bold">{agent.name}</h1>
          <p className="text-sm text-muted-foreground">{agent.tagline}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        {agent.demoAvailable && (
          <button
            onClick={() => setActiveTab('demo')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
              activeTab === 'demo'
                ? 'bg-primary text-primary-foreground shadow-custom'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Probar Demo
          </button>
        )}
        <button
          onClick={() => setActiveTab('reserve')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
            activeTab === 'reserve'
              ? 'bg-primary text-primary-foreground shadow-custom'
              : 'bg-muted text-muted-foreground hover:text-foreground'
          }`}
        >
          <Calendar className="w-4 h-4" /> Reservar Agente
        </button>
      </div>

      {/* Demo Tab */}
      {activeTab === 'demo' && (
        <Card>
          <CardContent className="p-0">
            {!demoStarted ? (
              <div className="p-8 text-center">
                <Sparkles className="w-12 h-12 text-primary mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">Probá {agent.name} en vivo</h2>
                <p className="text-muted-foreground mb-6">
                  Ingresá tus datos para iniciar una demo interactiva con {MAX_MESSAGES} mensajes gratuitos.
                </p>
                <div className="max-w-sm mx-auto space-y-4">
                  <div>
                    <Label>Nombre</Label>
                    <Input
                      placeholder="Tu nombre"
                      value={demoName}
                      onChange={e => setDemoName(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>Email</Label>
                    <Input
                      type="email"
                      placeholder="tu@email.com"
                      value={demoEmail}
                      onChange={e => setDemoEmail(e.target.value)}
                    />
                  </div>
                  {demoError && <p className="text-sm text-destructive">{demoError}</p>}
                  <Button onClick={startDemo} disabled={sending} className="w-full gap-2">
                    {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    Iniciar Demo
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col h-[500px]">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((msg, idx) => (
                    <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        msg.role === 'assistant' ? 'bg-primary/10' : 'bg-muted'
                      }`}>
                        {msg.role === 'assistant' ? (
                          <Bot className="w-4 h-4 text-primary" />
                        ) : (
                          <User className="w-4 h-4 text-muted-foreground" />
                        )}
                      </div>
                      <div className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm ${
                        msg.role === 'assistant'
                          ? 'bg-muted text-foreground'
                          : 'bg-primary text-primary-foreground'
                      }`}>
                        {msg.content}
                      </div>
                    </div>
                  ))}
                  {sending && (
                    <div className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <Bot className="w-4 h-4 text-primary" />
                      </div>
                      <div className="bg-muted rounded-xl px-4 py-2.5">
                        <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="border-t border-border p-4">
                  {messagesUsed >= MAX_MESSAGES ? (
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-3">
                        ¡Demo completada! ¿Te gustó lo que viste?
                      </p>
                      <Button onClick={() => setActiveTab('reserve')} className="gap-2">
                        <Calendar className="w-4 h-4" /> Reservar este Agente
                      </Button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Escribí tu mensaje..."
                        value={inputMsg}
                        onChange={e => setInputMsg(e.target.value)}
                        onKeyDown={handleKeyDown}
                        disabled={sending}
                        className="flex-1"
                      />
                      <Button onClick={sendMessage} disabled={sending || !inputMsg.trim()} size="icon">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground text-center mt-2">
                    {messagesUsed}/{MAX_MESSAGES} mensajes utilizados
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Reserve Tab */}
      {activeTab === 'reserve' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">Reservar {agent.name}</CardTitle>
            <p className="text-sm text-muted-foreground">
              Completá el formulario y nos pondremos en contacto en menos de 24 horas.
            </p>
          </CardHeader>
          <CardContent>
            {resSuccess ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-green-500" />
                </div>
                <h3 className="text-xl font-bold mb-2">¡Reserva Enviada!</h3>
                <p className="text-muted-foreground mb-6">
                  Recibimos tu solicitud para {agent.name}. Un especialista te contactará pronto.
                </p>
                <Link href="/catalogo">
                  <Button variant="outline">Explorar más agentes</Button>
                </Link>
              </div>
            ) : (
              <form onSubmit={submitReservation} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label>Nombre completo *</Label>
                    <Input
                      required
                      placeholder="Juan Pérez"
                      value={resForm.userName}
                      onChange={e => setResForm(f => ({ ...f, userName: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Email *</Label>
                    <Input
                      required
                      type="email"
                      placeholder="juan@empresa.com"
                      value={resForm.userEmail}
                      onChange={e => setResForm(f => ({ ...f, userEmail: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Empresa</Label>
                    <Input
                      placeholder="Mi Empresa SRL"
                      value={resForm.company}
                      onChange={e => setResForm(f => ({ ...f, company: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Teléfono</Label>
                    <Input
                      placeholder="+54 11 1234-5678"
                      value={resForm.phone}
                      onChange={e => setResForm(f => ({ ...f, phone: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Industria</Label>
                    <SimpleSelect
                      value={resForm.industry}
                      onChange={e => setResForm(f => ({ ...f, industry: e.target.value }))}
                    >
                      <option value="">Seleccioná una industria</option>
                      {industryOptions.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </SimpleSelect>
                  </div>
                  <div>
                    <Label>Plan de interés</Label>
                    <SimpleSelect
                      value={resForm.planInterest}
                      onChange={e => setResForm(f => ({ ...f, planInterest: e.target.value }))}
                    >
                      <option value="">Seleccioná un plan</option>
                      {planInterestOptions.map(opt => (
                        <option key={opt.value} value={opt.value}>{opt.label}</option>
                      ))}
                    </SimpleSelect>
                  </div>
                </div>
                <div>
                  <Label>¿Cómo usarías este agente? *</Label>
                  <Textarea
                    required
                    placeholder="Describí brevemente tu caso de uso..."
                    value={resForm.useCase}
                    onChange={e => setResForm(f => ({ ...f, useCase: e.target.value }))}
                    rows={3}
                  />
                </div>
                {resError && <p className="text-sm text-destructive">{resError}</p>}
                <Button type="submit" disabled={resLoading} className="w-full gap-2">
                  {resLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calendar className="w-4 h-4" />}
                  Enviar Reserva
                </Button>
                <p className="text-xs text-muted-foreground text-center">
                  Sin compromiso. Te contactamos en menos de 24hs hábiles.
                </p>
              </form>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
