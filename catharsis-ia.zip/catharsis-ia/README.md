# Catharsis IA

Marketplace de Agentes de Inteligencia Artificial para PyMEs latinoamericanas.

## Stack Tecnológico

- **Frontend:** Next.js 14 (App Router) + React 18 + TypeScript + Tailwind CSS
- **Backend:** Next.js API Routes + Prisma ORM
- **Database:** PostgreSQL
- **Auth:** JWT + bcrypt + Sessions en DB
- **Integraciones:** OpenAI, Stripe, MercadoPago, Postmark, n8n

## Estructura del Proyecto

```
catharsis-ia/
├── prisma/           # Schema y seed de la base de datos
├── src/
│   ├── app/          # Pages y API routes (App Router)
│   ├── components/   # Componentes React (layout, ui, agents)
│   ├── lib/          # Utilidades (auth, db, api, email, etc.)
│   └── hooks/        # Custom hooks (useAuth con Zustand)
```

## Setup Rápido

```bash
# 1. Instalar dependencias
npm install

# 2. Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales

# 3. Crear base de datos y ejecutar migraciones
npx prisma migrate dev --name init

# 4. Sembrar datos iniciales
npm run db:seed

# 5. Iniciar en desarrollo
npm run dev
```

## Páginas

| Ruta | Descripción |
|------|------------|
| `/` | Home (hero, features, pricing, CTA) |
| `/catalogo` | Catálogo de agentes con búsqueda y filtros |
| `/agente/[slug]` | Detalle de agente (capacidades, FAQs, pricing) |
| `/demo/[slug]` | Demo interactiva + formulario de reserva |
| `/login` | Inicio de sesión |
| `/registro` | Registro de cuenta |
| `/dashboard` | Dashboard del usuario |
| `/admin` | Panel de administración (reservas, métricas) |

## API Routes

| Método | Ruta | Descripción |
|--------|------|------------|
| POST | `/api/auth/register` | Registro |
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/logout` | Logout |
| GET | `/api/auth/me` | Usuario actual |
| POST | `/api/auth/refresh` | Refresh token |
| GET | `/api/agents` | Listar agentes |
| GET | `/api/agents/[slug]` | Detalle de agente |
| POST | `/api/demos` | Crear sesión demo |
| POST | `/api/demos/[id]/message` | Enviar mensaje demo |
| POST | `/api/reservations` | Crear reserva |
| GET | `/api/reservations` | Listar reservas (admin) |
| PATCH | `/api/reservations/[id]` | Actualizar reserva (admin) |
| GET | `/api/admin/dashboard` | Stats del dashboard (admin) |
| POST | `/api/webhooks/stripe` | Webhook Stripe |
| POST | `/api/webhooks/mercadopago` | Webhook MercadoPago |
| GET | `/api/health` | Health check |

## Credenciales por Defecto (Seed)

- **Admin:** admin@catharsis-ia.com / CatharsisAdmin2025!

## Deployment

```bash
# Build de producción
npm run build

# Iniciar en producción
npm start

# Migraciones en producción
npm run db:migrate:prod
```

## Scripts

```bash
npm run dev          # Desarrollo
npm run build        # Build producción
npm start            # Iniciar producción
npm run lint         # Linting
npm run db:seed      # Sembrar datos
npm run db:studio    # Prisma Studio
npm run db:migrate:prod  # Migraciones producción
```
