import { PrismaClient } from '@prisma/client';
import { hash } from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // ─── PLANS ────────────────────────────────────────────────────
  const plans = await Promise.all([
    prisma.plan.upsert({
      where: { slug: 'starter' },
      update: {},
      create: {
        name: 'Starter',
        slug: 'starter',
        description: '1 agente IA + soporte email + integraciones básicas',
        priceMonthly: 49,
        priceYearly: 470,
        setupFee: 299,
        currency: 'USD',
        limits: {
          max_agents: 1,
          max_actions_month: 1000,
          max_integrations: 3,
          max_team_members: 2,
          support_level: 'email',
          sla_hours: 48,
        },
        features: [
          '1 agente IA activo',
          '1.000 acciones/mes',
          '3 integraciones',
          'Soporte por email (48h)',
          'Dashboard básico',
          'Reportes semanales',
        ],
        sortOrder: 1,
      },
    }),
    prisma.plan.upsert({
      where: { slug: 'pro' },
      update: {},
      create: {
        name: 'Pro',
        slug: 'pro',
        description: 'Hasta 5 agentes + soporte prioritario + integraciones ilimitadas',
        priceMonthly: 199,
        priceYearly: 1910,
        setupFee: 599,
        currency: 'USD',
        limits: {
          max_agents: 5,
          max_actions_month: 10000,
          max_integrations: -1,
          max_team_members: 10,
          support_level: 'priority',
          sla_hours: 12,
        },
        features: [
          'Hasta 5 agentes IA',
          '10.000 acciones/mes',
          'Integraciones ilimitadas',
          'Soporte prioritario (12h)',
          'Dashboard avanzado',
          'Reportes diarios',
          'API access',
          'Onboarding personalizado',
        ],
        sortOrder: 2,
      },
    }),
    prisma.plan.upsert({
      where: { slug: 'enterprise' },
      update: {},
      create: {
        name: 'Enterprise',
        slug: 'enterprise',
        description: 'Agentes ilimitados + soporte dedicado + SLA garantizado',
        priceMonthly: 0,
        priceYearly: 0,
        setupFee: 0,
        currency: 'USD',
        limits: {
          max_agents: -1,
          max_actions_month: -1,
          max_integrations: -1,
          max_team_members: -1,
          support_level: 'dedicated',
          sla_hours: 4,
        },
        features: [
          'Agentes ilimitados',
          'Acciones ilimitadas',
          'Integraciones ilimitadas',
          'Account manager dedicado',
          'SLA garantizado (4h)',
          'Desarrollo custom',
          'On-premise opcional',
          'Training para equipo',
        ],
        sortOrder: 3,
      },
    }),
  ]);

  console.log(`✅ ${plans.length} planes creados`);

  // ─── SAMPLE AGENTS ────────────────────────────────────────────
  const agents = await Promise.all([
    prisma.agent.upsert({
      where: { slug: 'asistente-marketing-ia' },
      update: {},
      create: {
        name: 'Asistente de Marketing IA',
        slug: 'asistente-marketing-ia',
        tagline: 'Automatiza campañas, genera contenido y analiza métricas 24/7',
        description: 'Agente inteligente que gestiona tus campañas de marketing digital. Genera copy para redes sociales, analiza métricas de rendimiento y optimiza tu presupuesto publicitario con IA avanzada.',
        longDescription: 'Este agente transforma tu estrategia de marketing digital. Conecta con tus plataformas de ads, redes sociales y analytics para crear un flujo de trabajo completamente automatizado. Genera contenido personalizado para cada canal, A/B testea automáticamente y te envía reportes con insights accionables.',
        category: 'Marketing',
        capabilities: ['Generación de contenido', 'Análisis de métricas', 'A/B Testing automático', 'Optimización de presupuesto', 'Programación de posts', 'Reportes inteligentes'],
        integrations: ['Meta Ads', 'Google Ads', 'Instagram', 'LinkedIn', 'Google Analytics', 'Sheets'],
        iconName: 'Megaphone',
        status: 'active',
        pricingBasic: 49,
        pricingPro: 99,
        pricingEnterprise: 199,
        demoAvailable: true,
        featured: true,
        demoPrompt: `Eres un asistente de marketing digital experto de Catharsis IA. Ayudas a las empresas a optimizar sus campañas, generar contenido y analizar métricas. Responde de forma práctica y accionable. Siempre sugiere automatizaciones que el agente puede hacer. Limita tus respuestas a 150 palabras. Si te preguntan algo fuera de marketing, redirige amablemente al tema.`,
        faqs: [
          { question: '¿Cuánto tiempo toma la configuración?', answer: '48 horas desde la confirmación del pago hasta el agente activo.' },
          { question: '¿Funciona con mi CRM?', answer: 'Sí, nos integramos con HubSpot, Salesforce, Pipedrive y cualquier CRM con API.' },
          { question: '¿Puedo personalizarlo?', answer: 'Absolutamente. Cada agente se configura según tu industria, tono y objetivos.' },
        ],
        howItWorks: 'El agente se conecta a tus plataformas de marketing y aprende de tus campañas anteriores. Genera contenido nuevo, programa publicaciones y monitorea rendimiento automáticamente.',
        implementation: '1. Llamada de onboarding (30min)\n2. Conexión de plataformas\n3. Configuración de tono y marca\n4. Testing con campañas reales\n5. Deploy en producción',
        installTime: '48 horas',
        requirements: '• Acceso a cuentas de ads y redes sociales\n• Brand guidelines (opcional)\n• Historial de campañas anteriores',
        automatedTasks: ['Generación de copy para redes sociales', 'Análisis diario de métricas', 'Optimización de pujas en ads', 'Reportes semanales automáticos', 'Alertas de rendimiento anormal'],
        sortOrder: 1,
      },
    }),
    prisma.agent.upsert({
      where: { slug: 'agente-ventas-automatizado' },
      update: {},
      create: {
        name: 'Agente de Ventas Automatizado',
        slug: 'agente-ventas-automatizado',
        tagline: 'Califica leads, hace follow-up y cierra reuniones mientras dormís',
        description: 'Agente de ventas que trabaja 24/7. Califica leads entrantes, envía secuencias de follow-up personalizadas y agenda reuniones directamente en tu calendario.',
        longDescription: 'Tu vendedor incansable. Este agente monitorea todos tus canales de leads (web, email, WhatsApp), califica automáticamente según tu ICP, envía secuencias de nurturing personalizadas y cuando detecta intención de compra, agenda la reunión directamente en tu calendario.',
        category: 'Ventas',
        capabilities: ['Lead scoring automático', 'Secuencias de email', 'Follow-up inteligente', 'Agendamiento automático', 'Integración CRM', 'Reportes de pipeline'],
        integrations: ['HubSpot', 'Calendly', 'Gmail', 'WhatsApp', 'Sheets', 'Slack'],
        iconName: 'TrendingUp',
        status: 'active',
        pricingBasic: 59,
        pricingPro: 119,
        pricingEnterprise: 249,
        demoAvailable: true,
        featured: true,
        demoPrompt: `Eres un agente de ventas B2B experto de Catharsis IA. Ayudas a calificar leads, diseñar secuencias de follow-up y optimizar el pipeline de ventas. Responde de forma directa y orientada a resultados. Muestra cómo automatizarías tareas de ventas. Limita respuestas a 150 palabras.`,
        faqs: [
          { question: '¿Se integra con mi CRM actual?', answer: 'Sí, compatible con HubSpot, Salesforce, Pipedrive, Monday CRM y más.' },
          { question: '¿Cómo califica los leads?', answer: 'Usa un scoring basado en comportamiento, datos demográficos e interacción con tu contenido.' },
          { question: '¿Puede enviar emails?', answer: 'Sí, envía secuencias personalizadas por email y WhatsApp con seguimiento automático.' },
        ],
        howItWorks: 'El agente monitorea tus canales de entrada, califica automáticamente cada lead según tu perfil de cliente ideal, y ejecuta secuencias de nurturing hasta que el lead está listo para una reunión.',
        installTime: '48-72 horas',
        automatedTasks: ['Calificación de leads entrantes', 'Secuencias de email automáticas', 'Follow-up por WhatsApp', 'Agendamiento de reuniones', 'Actualización de CRM', 'Alertas de leads calientes'],
        sortOrder: 2,
      },
    }),
    prisma.agent.upsert({
      where: { slug: 'soporte-al-cliente-ia' },
      update: {},
      create: {
        name: 'Soporte al Cliente IA',
        slug: 'soporte-al-cliente-ia',
        tagline: 'Responde consultas, resuelve tickets y escala solo lo necesario',
        description: 'Agente de atención al cliente que maneja el 80% de las consultas sin intervención humana. Integra tu base de conocimiento y responde 24/7 por múltiples canales.',
        category: 'Atencion_al_Cliente',
        capabilities: ['Respuesta automática 24/7', 'Base de conocimiento IA', 'Escalamiento inteligente', 'Análisis de sentimiento', 'Multi-canal', 'Reportes de satisfacción'],
        integrations: ['WhatsApp', 'Email', 'Slack', 'Notion', 'Zendesk', 'Intercom'],
        iconName: 'Headphones',
        status: 'active',
        pricingBasic: 39,
        pricingPro: 89,
        demoAvailable: true,
        featured: false,
        demoPrompt: `Eres un agente de soporte al cliente experto de Catharsis IA. Demostras cómo la automatización puede resolver el 80% de las consultas de soporte. Eres empático, eficiente y orientado a soluciones. Limita respuestas a 150 palabras.`,
        faqs: [
          { question: '¿Qué porcentaje de tickets resuelve solo?', answer: 'En promedio, nuestros agentes resuelven el 78% de los tickets sin intervención humana.' },
        ],
        installTime: '48 horas',
        sortOrder: 3,
      },
    }),
    prisma.agent.upsert({
      where: { slug: 'analista-de-datos-ia' },
      update: {},
      create: {
        name: 'Analista de Datos IA',
        slug: 'analista-de-datos-ia',
        tagline: 'Transforma tus datos en insights accionables automáticamente',
        description: 'Agente que conecta tus fuentes de datos, genera reportes automáticos y detecta patrones que humanos pasarían por alto.',
        category: 'Datos',
        capabilities: ['ETL automático', 'Dashboards inteligentes', 'Detección de anomalías', 'Reportes programados', 'Predicciones ML', 'Alertas en tiempo real'],
        integrations: ['Google Sheets', 'BigQuery', 'PostgreSQL', 'Notion', 'Slack', 'Email'],
        iconName: 'BarChart3',
        status: 'active',
        pricingBasic: 69,
        pricingPro: 139,
        demoAvailable: true,
        featured: false,
        demoPrompt: `Eres un analista de datos experto de Catharsis IA. Ayudas a las empresas a entender sus datos y tomar decisiones basadas en evidencia. Responde con insights claros y accionables. Limita respuestas a 150 palabras.`,
        installTime: '72 horas',
        sortOrder: 4,
      },
    }),
    prisma.agent.upsert({
      where: { slug: 'asistente-legal-ia' },
      update: {},
      create: {
        name: 'Asistente Legal IA',
        slug: 'asistente-legal-ia',
        tagline: 'Revisa contratos, genera documentos y alerta sobre vencimientos',
        description: 'Agente especializado en gestión legal empresarial. Revisa contratos, genera documentos estándar y te alerta sobre plazos y vencimientos críticos.',
        category: 'Legal',
        capabilities: ['Revisión de contratos', 'Generación de documentos', 'Alertas de vencimiento', 'Compliance automático', 'Base legal consultable'],
        integrations: ['Google Drive', 'Notion', 'Email', 'Calendar', 'Slack'],
        iconName: 'Scale',
        status: 'active',
        pricingBasic: 79,
        pricingPro: 159,
        demoAvailable: true,
        featured: false,
        demoPrompt: `Eres un asistente legal IA de Catharsis IA. Ayudas con revisión de contratos, gestión de documentos legales y compliance. No das asesoramiento legal definitivo sino que asistes en la gestión. Limita respuestas a 150 palabras.`,
        installTime: '72 horas',
        sortOrder: 5,
      },
    }),
    prisma.agent.upsert({
      where: { slug: 'automatizador-de-operaciones' },
      update: {},
      create: {
        name: 'Automatizador de Operaciones',
        slug: 'automatizador-de-operaciones',
        tagline: 'Conecta tus herramientas y elimina tareas repetitivas',
        description: 'Agente que automatiza tus procesos operativos internos. Conecta herramientas, sincroniza datos y elimina el trabajo manual repetitivo.',
        category: 'Operaciones',
        capabilities: ['Workflows automáticos', 'Sincronización de datos', 'Notificaciones inteligentes', 'Gestión de tareas', 'Integración de herramientas', 'Monitoreo de procesos'],
        integrations: ['Slack', 'Notion', 'Sheets', 'Asana', 'Monday', 'Email', 'Calendar'],
        iconName: 'Cog',
        status: 'active',
        pricingBasic: 49,
        pricingPro: 99,
        demoAvailable: true,
        featured: false,
        demoPrompt: `Eres un experto en automatización de operaciones de Catharsis IA. Ayudas a las empresas a identificar procesos manuales que se pueden automatizar y diseñar workflows eficientes. Limita respuestas a 150 palabras.`,
        installTime: '48 horas',
        sortOrder: 6,
      },
    }),
  ]);

  console.log(`✅ ${agents.length} agentes creados`);

  // ─── SUPERADMIN USER ──────────────────────────────────────────
  const hashedPassword = await hash('CatharsisAdmin2025!', 12);
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@catharsis-ia.com' },
    update: {},
    create: {
      email: 'admin@catharsis-ia.com',
      passwordHash: hashedPassword,
      fullName: 'Admin Catharsis',
      role: 'superadmin',
      status: 'active',
      emailVerifiedAt: new Date(),
    },
  });

  console.log(`✅ Superadmin creado: ${adminUser.email}`);
  console.log('\n🎉 Seed completado!');
}

main()
  .catch((e) => {
    console.error('❌ Error en seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
